<?php
session_start();
include 'db.php';

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Handle question actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $question_id = $_GET['id'];
    $action = $_GET['action'];
    
    if ($action === 'delete') {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // First delete all votes for answers of this question
            $delete_votes_query = "DELETE av FROM answer_votes av 
                                 INNER JOIN answers a ON av.answer_id = a.id 
                                 WHERE a.question_id = ?";
            $stmt = $conn->prepare($delete_votes_query);
            $stmt->bind_param('i', $question_id);
            $stmt->execute();
            
            // Then delete all answers
            $delete_answers_query = "DELETE FROM answers WHERE question_id = ?";
            $stmt = $conn->prepare($delete_answers_query);
            $stmt->bind_param('i', $question_id);
            $stmt->execute();
            
            // Finally delete the question
            $delete_query = "DELETE FROM questions WHERE id = ?";
            $stmt = $conn->prepare($delete_query);
            $stmt->bind_param('i', $question_id);
            $stmt->execute();
            
            // If all operations successful, commit transaction
            $conn->commit();
            $_SESSION['message'] = 'Question and all related content deleted successfully!';
            $_SESSION['message_type'] = 'success';
            
        } catch (Exception $e) {
            // If any operation fails, rollback all changes
            $conn->rollback();
            $_SESSION['message'] = 'Error deleting question: ' . $e->getMessage();
            $_SESSION['message_type'] = 'error';
        }
        
        header("Location: questions.php");
        exit();
    }
}

// Fetch questions with user information
$questions_query = "SELECT q.*, u.name as asked_by, 
                   (SELECT COUNT(*) FROM answers WHERE question_id = q.id) as answer_count 
                   FROM questions q 
                   JOIN users u ON q.user_id = u.id 
                   ORDER BY q.created_at DESC";
$questions_result = $conn->query($questions_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --background-dark: #0f172a;
            --card-background: #1e293b;
            --text-color: #f8fafc;
            --border-color: #334155;
        }

        body {
            background-color: var(--background-dark);
            color: var(--text-color);
            min-height: 100vh;
        }

        .card {
            background-color: var(--card-background);
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
        }

        .table {
            color: var(--text-color);
        }

        .table th {
            background-color: var(--border-color);
            color: var(--text-color);
            font-weight: 600;
        }

        .question-content {
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .btn-delete {
            background-color: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: none;
            transition: all 0.2s;
        }

        .btn-delete:hover {
            background-color: #ef4444;
            color: white;
        }

        .btn-view {
            background-color: rgba(37, 99, 235, 0.1);
            color: #2563eb;
            border: none;
            transition: all 0.2s;
        }

        .btn-view:hover {
            background-color: #2563eb;
            color: white;
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="container py-4">
    <?php
    if (isset($_SESSION['message'])) {
        $alert_class = $_SESSION['message_type'] === 'error' ? 'alert-danger' : 'alert-success';
        echo '<div class="alert ' . $alert_class . ' alert-dismissible fade show" role="alert">
                ' . $_SESSION['message'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
    ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Manage Questions</h2>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Subject</th>
                            <th>Question</th>
                            <th>Asked By</th>
                            <th>Answers</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($questions_result->num_rows > 0) {
                            while ($question = $questions_result->fetch_assoc()) {
                                echo "<tr>
                                        <td>" . $question['id'] . "</td>
                                        <td>" . htmlspecialchars($question['subject']) . "</td>
                                        <td class='question-content'>" . htmlspecialchars($question['question']) . "</td>
                                        <td>" . htmlspecialchars($question['asked_by']) . "</td>
                                        <td>" . $question['answer_count'] . "</td>
                                        <td>" . date('M d, Y', strtotime($question['created_at'])) . "</td>
                                        <td>
                                            <a href='../view-answers.php?question_id=" . $question['id'] . "' class='btn btn-view btn-sm me-2'>
                                                <i class='fas fa-eye me-1'></i>View
                                            </a>
                                            <button class='btn btn-delete btn-sm' onclick='confirmDelete(" . $question['id'] . ")'>
                                                <i class='fas fa-trash-alt me-1'></i>Delete
                                            </button>
                                        </td>
                                    </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>No questions found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this question? This action cannot be undone.</p>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function confirmDelete(id) {
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    const confirmBtn = document.getElementById('confirmDelete');
    
    confirmBtn.onclick = function() {
        window.location.href = `questions.php?action=delete&id=${id}`;
    };
    
    modal.show();
}
</script>

</body>
</html>