<?php
include 'db.php';

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Get admin info
$admin_id = $_SESSION['admin_id'];
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --warning-color: #f59e0b;
            --background-dark: #0f172a;
            --card-background: #1e293b;
            --text-color: #f8fafc;
            --border-color: #334155;
        }

        body {
            background-color: var(--background-dark);
            color: var(--text-color);
            min-height: 100vh;
        }

        /* Navbar Styles */
        .navbar {
            background-color: var(--card-background) !important;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 0.75rem 1rem;
        }

        .navbar-brand {
            font-weight: 600;
            font-size: 1.25rem;
            color: var(--text-color) !important;
        }

        .nav-link {
            color: var(--text-color) !important;
            opacity: 0.8;
            transition: all 0.2s;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
        }

        .nav-link:hover, .nav-link.active {
            opacity: 1;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .nav-link i {
            margin-right: 0.5rem;
        }

        /* User Dropdown Styles */
        .user-dropdown {
            background-color: var(--card-background);
            border: 1px solid var(--border-color);
        }

        .user-dropdown .dropdown-item {
            color: var(--text-color);
        }

        .user-dropdown .dropdown-item:hover {
            background-color: rgb(255, 255, 255);
        }

        .user-dropdown .dropdown-divider {
            border-color: var(--border-color);
        }

        .user-dropdown .text-muted {
            color: var(--text-color) !important;
            opacity: 0.7;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            margin-right: 0.5rem;
        }

        /* Notification Styles */
        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            transform: translate(50%, -50%);
            background-color: var(--primary-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.75rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .notification-icon {
            position: relative;
        }
        .user-dropdown .dropdown-item-text {
            color: rgba(255, 255, 255, 0.9) !important;
        }

        .user-dropdown .dropdown-item-text .fw-bold {
            color: var(--text-color) !important;
        }

        .user-dropdown .dropdown-item-text small {
            color: rgba(255, 255, 255, 0.7) !important;
        }

        /* Common Card Styles */
        .card {
            background-color: var(--card-background);
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
            transition: transform 0.2s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-title {
            font-size: 0.875rem;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .card-value {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0;
            color: var(--text-color);
        }

        /* Common Table Styles */
        .table {
            background-color: var(--card-background);
            border-radius: 0.75rem;
            overflow: hidden;
        }

        .table th {
            background-color: var(--border-color);
            color: var(--text-color);
            font-weight: 600;
            border-bottom: none;
        }

        .table td {
            vertical-align: middle;
            border-color: var(--border-color);
        }

        /* Status Badge Styles */
        .status-badge {
            padding: 0.35rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-approved {
            background-color: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .status-pending {
            background-color: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .status-banned {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--danger-color);
        }

        /* Action Button Styles */
        .action-btn {
            padding: 0.25rem 0.75rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            font-weight: 500;
            transition: all 0.2s;
        }

        .btn-approve {
            background-color: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
            border: none;
        }

        .btn-approve:hover {
            background-color: var(--success-color);
            color: white;
        }

        .btn-ban {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--danger-color);
            border: none;
        }

        .btn-ban:hover {
            background-color: var(--danger-color);
            color: white;
        }

        .btn-unban {
            background-color: rgb(255, 255, 255);
            color: var(--warning-color);
            border: none;
        }

        .btn-unban:hover {
            background-color: var(--warning-color);
            color: white;
        }

        /* Alert Styles */
        .alert {
            border: none;
            border-radius: 0.75rem;
        }

        .alert-success {
            background-color: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .alert-error {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--danger-color);
        }

        /* Modal Styles */
        .modal-content {
            background-color: var(--card-background);
            border: 1px solid var(--border-color);
        }

        .modal-header {
            border-bottom-color: var(--border-color);
        }

        .modal-footer {
            border-top-color: var(--border-color);
        }

        /* Container Styles */
        .container {
            padding-top: 1.5rem;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-user-shield me-2"></i>Admin Panel
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="dashboard.php">
                        <i class="fas fa-tachometer-alt"></i>Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tutors.php">
                        <i class="fas fa-chalkboard-teacher"></i>Tutors
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="students.php">
                        <i class="fas fa-user-graduate"></i>Students
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="subjects.php">
                        <i class="fas fa-book"></i>Subjects
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="testimonials.php">
                        <i class="fas fa-book"></i>Testimonials
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="questions.php">
                        <i class="fas fa-question-circle"></i>Q&A Management
                    </a>
                </li>
              
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($admin['name'], 0, 1)); ?>
                        </div>
                        <span><?php echo $admin['name']; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end user-dropdown">
                        <li>
                            <div class="dropdown-item-text">
                                <div class="fw-bold"><?php echo $admin['name']; ?></div>
                                <small class="text-muted"><?php echo $admin['email']; ?></small>
                            </div>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
