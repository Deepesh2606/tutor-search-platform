<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include('db.php');

// Fetch user details if logged in
$user = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
}
?>

<link rel="stylesheet" href="assets/style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background: linear-gradient(90deg, #0F1C4D, #1E3A8A); box-shadow: 0 4px 15px rgba(0,0,0,0.2); backdrop-filter: blur(10px);">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="img/logo/logo.png" alt="Home Tutor Logo" class="img-fluid" style="height: 45px; margin-right: 10px; vertical-align: middle;">
      <span class="navbar-text d-none d-sm-inline" style="font-size: 26px; font-weight: 700; color: white; letter-spacing: 1px; vertical-align: middle;">
        TutorAtHome
      </span>
    </a>

    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
      aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
      <ul class="navbar-nav align-items-lg-center">
        <li class="nav-item">
          <a class="nav-link text-light px-3 py-2 rounded-3" href="index.php">
            <i class="fas fa-search me-2"></i><span class="d-none d-md-inline">Find Tutors</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light px-3 py-2 rounded-3" href="tutor_register.php">
            <i class="fas fa-chalkboard-teacher me-2"></i><span class="d-none d-md-inline">Become a Tutor</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light px-3 py-2 rounded-3" href="qna.php">
            <i class="fas fa-question-circle me-2"></i><span class="d-none d-md-inline">Q&A</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light px-3 py-2 rounded-3" href="mybookings.php">
            <i class="fas fa-calendar-check me-2"></i><span class="d-none d-md-inline">My Bookings</span>
          </a>
        </li>
        <?php if ($user): ?>
          <li class="nav-item">
            <a class="nav-link text-light px-3 py-2 rounded-3" href="profile.php">
              <i class="fas fa-user-circle me-2"></i><span class="d-none d-md-inline">Dashboard</span>
            </a>
          </li>
        <?php endif; ?>
      </ul>

      <div class="d-flex align-items-center ms-lg-4 mt-3 mt-lg-0">
        <?php if ($user): ?>
          <div class="d-flex align-items-center">
            <div class="text-light me-3 d-flex align-items-center">
              <i class="fas fa-user-circle me-2"></i>
              <span class="d-none d-md-inline">Hello, <?= htmlspecialchars($user['name']); ?></span>
            </div>
            <a href="logout.php" class="btn btn-outline-light btn-sm px-3 py-2 rounded-3">
              <i class="fas fa-sign-out-alt me-2"></i><span class="d-none d-md-inline">Logout</span>
            </a>
          </div>
        <?php else: ?>
          <div class="d-flex gap-2">
            <a href="login.php?role=student" class="btn btn-outline-light btn-sm px-3 py-2 rounded-3">
              <i class="fas fa-user-graduate me-2"></i><span class="d-none d-md-inline">Student Login</span>
            </a>
            <a href="tutor_login.php?role=tutor" class="btn btn-outline-light btn-sm px-3 py-2 rounded-3">
              <i class="fas fa-chalkboard-teacher me-2"></i><span class="d-none d-md-inline">Tutor Login</span>
            </a>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<style>
.nav-link {
  transition: all 0.3s ease;
  margin: 0 -5px;
  position: relative;
  font-weight: 500;
  white-space: nowrap;
}

.nav-link:hover {
  background-color: rgba(255, 255, 255, 0.15);
  transform: translateY(-2px);
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.nav-link::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: rgba(255, 255, 255, 0.3);
  transform: scaleX(0);
  transition: transform 0.3s ease;
}

.nav-link:hover::after {
  transform: scaleX(1);
}

.btn-outline-light {
  transition: all 0.3s ease;
  border-width: 2px;
  font-weight: 500;
  white-space: nowrap;
}

.btn-outline-light:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 255, 255, 0.2);
  background-color: rgba(255, 255, 255, 0.1);
}

.navbar {
  padding: 0.8rem 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.navbar-brand {
  transition: transform 0.3s ease;
}

.navbar-brand:hover {
  transform: translateY(-2px);
}

@media (max-width: 991.98px) {
  .navbar-nav {
    padding: 1rem 0;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 10px;
  }
  
  .nav-link {
    padding: 0.8rem 1.2rem !important;
    margin: 0.2rem 0;
  }

  .navbar-collapse {
    background: linear-gradient(90deg, #0F1C4D, #1E3A8A);
    padding: 1rem;
    border-radius: 10px;
    margin-top: 1rem;
  }

  .d-flex.gap-2 {
    flex-direction: column;
    width: 100%;
  }

  .d-flex.gap-2 .btn {
    width: 100%;
    margin-bottom: 0.5rem;
  }
}

@media (max-width: 576px) {
  .navbar-brand img {
    height: 35px;
  }
  
  .navbar-text {
    font-size: 20px;
  }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
