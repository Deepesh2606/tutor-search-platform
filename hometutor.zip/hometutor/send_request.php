<?php
include("db.php");
session_start();

// Assuming the tutor request details are submitted via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $tutor_id = $_POST['tutor_id'];
    $student_id = $_POST['student_id'];
    $tutor_phone = $_POST['tutor_phone'];  // Getting the tutor's phone number

    // You can now use this phone number to send an SMS, store it in a database, or for any other functionality

    // For example, save this request to a database (this part is just an example, adjust to your needs)
    $stmt = $conn->prepare("INSERT INTO tutor_requests (student_id, tutor_id, tutor_phone) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $student_id, $tutor_id, $tutor_phone);
    if ($stmt->execute()) {
        // Redirect or provide feedback after successful request submission
        header("Location: request_sent.php?msg=Request sent successfully!");
    } else {
        // Handle error case
        echo "Error sending request.";
    }
}
?>
