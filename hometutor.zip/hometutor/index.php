<?php
include("db.php");
session_start();
include 'header.php';

// Get current user's location if logged in
$user_latitude = $user_longitude = null;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_stmt = $conn->prepare("SELECT latitude, longitude FROM users WHERE id = ?");
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    if ($user_result->num_rows == 1) {
        $user_row = $user_result->fetch_assoc();
        $user_latitude = $user_row['latitude'];
        $user_longitude = $user_row['longitude'];
    }
}

$tutors = [];

// Search for tutors
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php?msg=Please login or signup to search for a tutor");
        exit;
    }

    // Check if class_level and subject are set in POST request
    $selected_class = isset($_POST['class_level']) ? $_POST['class_level'] : null;
    $selected_subject = isset($_POST['subject']) ? $_POST['subject'] : null;

    if ($selected_class && $selected_subject) {
        $query = "
            SELECT td.*, u.latitude, u.longitude, u.name, u.profile_picture, u.phone
            FROM tutor_details td
            JOIN users u ON td.user_id = u.id
            WHERE td.subject_expertise = ? AND u.status = 'approved'
        ";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $selected_subject);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $teaching_levels = explode(", ", $row['teaching_levels']);
            if (in_array($selected_class, $teaching_levels)) {
                $lat = $row['latitude'];
                $lon = $row['longitude'];

                // Calculate distance if user location is available
                if ($user_latitude && $user_longitude) {
                    $distance = 6371 * acos(
                        cos(deg2rad($user_latitude)) * cos(deg2rad($lat)) *
                        cos(deg2rad($lon) - deg2rad($user_longitude)) +
                        sin(deg2rad($user_latitude)) * sin(deg2rad($lat))
                    );
                    $row['distance'] = round($distance, 2);
                } else {
                    $row['distance'] = null;
                }
                
                $tutors[] = $row;
            }
        }
    }
}
?>

<!-- Full Width Hero Section with Gradient -->
<div class="py-4 py-md-5" style="background: linear-gradient(135deg, #0F1C4D, #1E3A8A); min-height: auto; position: relative; overflow: hidden;">
    <div class="container position-relative z-1">
        <div class="text-center text-white py-3 py-md-4">
            <h2 class="display-4 fw-bold mb-2 mb-md-3" style="text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">Find Your Perfect Tutor</h2>
            <p class="lead mb-3 mb-md-4" style="text-shadow: 1px 1px 2px rgba(0,0,0,0.2);">Discover qualified tutors within 10 KM of your location</p>
        </div>

        <!-- Search Form -->
        <div class="d-flex justify-content-center">
            <form method="post" class="bg-white p-3 p-md-4 shadow-lg rounded-4 w-100" style="max-width: 800px; backdrop-filter: blur(10px); background: rgba(255, 255, 255, 0.95);">
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label for="class_level" class="form-label fw-semibold">Select Class Level</label>
                        <select name="class_level" id="class_level" class="form-select form-select-lg" required style="border: 2px solid #e9ecef; transition: all 0.3s ease;">
                            <option value="">--Select Class Level--</option>
                            <option value="Class 1-5">Class 1–5</option>
                            <option value="Class 6-8">Class 6–8</option>
                            <option value="Class 9-10">Class 9–10</option>
                            <option value="Class 11-12 Science">Class 11–12 (Science)</option>
                            <option value="Class 11-12 Commerce">Class 11–12 (Commerce)</option>
                            <option value="Class 11-12 Arts">Class 11–12 (Arts)</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-6">
                        <label for="subject" class="form-label fw-semibold">Select Subject</label>
                        <select name="subject" id="subject" class="form-select form-select-lg" required style="border: 2px solid #e9ecef; transition: all 0.3s ease;">
                            <option value="">--Select Subject--</option>
                            <?php
                            $subject_query = $conn->query("SELECT * FROM subjects ORDER BY name ASC");
                            while ($row = $subject_query->fetch_assoc()) {
                                echo "<option value='{$row['name']}'>{$row['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="col-12 text-center mt-2">
                        <button type="submit" class="btn btn-primary btn-lg px-4 px-md-5 py-2 py-md-3 fw-bold" style="background: linear-gradient(135deg, #1E3A8A, #0F1C4D); border: none; transition: all 0.3s ease;">
                            Search Tutors
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Browse All Tutors Link -->
        <div class="text-center mt-3">
            <a href="tutors_by_subject.php" class="btn btn-outline-light btn-lg" style="border: 2px solid white; transition: all 0.3s ease;">
                <i class="fas fa-list me-2"></i>Browse All Tutors by Subject
            </a>
        </div>
    </div>
</div>

<!-- Tutors List -->
<div id="tutors-section" class="container py-4 py-md-5">
    <h4 class="mb-4 text-center fw-bold display-5" style="color: #0F1C4D;">🌟 Available Tutors</h4>
    <div class="row g-4">
        <?php
        if (!empty($tutors)) {
            foreach ($tutors as $tutor) {
                $profile_picture = $tutor['profile_picture'] ? 'img/profilepic/' . htmlspecialchars($tutor['profile_picture']) : 'img/default-profile.png';
                ?>
                <div class="col-12 col-sm-6 col-md-4">
                    <div class="card h-100 border-0 shadow-sm hover-shadow transition-all tutor-card" style="border-radius: 15px; overflow: hidden; background: #fff;">
                        <div class="card-body p-3 p-md-4 text-center">
                            <div class="tutor-image-container mb-3 mb-md-4">
                                <img src="<?= $profile_picture ?>" alt="Profile Picture" class="rounded-circle tutor-image" style="width: 100px; height: 100px; object-fit: cover; border: 4px solid #f8f9fa; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
                            </div>
                            <h5 class="card-title fw-bold mb-2 mb-md-3" style="color: #0F1C4D;"><?= htmlspecialchars($tutor['name']) ?></h5>
                            <div class="tutor-details text-muted mb-3">
                                <p class="mb-2 small"><i class="fas fa-book me-2" style="color: #1E3A8A;"></i><strong>Subject:</strong> <?= htmlspecialchars($tutor['subject_expertise']) ?></p>
                                <p class="mb-2 small"><i class="fas fa-graduation-cap me-2" style="color: #1E3A8A;"></i><strong>Classes:</strong> <?= htmlspecialchars($tutor['teaching_levels']) ?></p>
                                <p class="mb-2 small"><i class="fas fa-map-marker-alt me-2" style="color: #1E3A8A;"></i><strong>Distance:</strong> 
                                    <?php 
                                    if (isset($tutor['distance'])) {
                                        echo $tutor['distance'] . ' KM';
                                    } else {
                                        echo 'Location not available';
                                    }
                                    ?>
                                </p>
                                <p class="mb-2 small"><i class="fas fa-clock me-2" style="color: #1E3A8A;"></i><strong>Availability:</strong> <?= htmlspecialchars($tutor['availability'] ?? 'Not specified') ?></p>
                                <p class="mb-3 small"><i class="fas fa-certificate me-2" style="color: #1E3A8A;"></i><strong>Qualification:</strong> <?= htmlspecialchars($tutor['qualifications']) ?></p>
                            </div>

                            <form action="send_request.php" method="post" class="mt-auto">
                                <input type="hidden" name="tutor_id" value="<?= $tutor['user_id'] ?>">
                                <input type="hidden" name="student_id" value="<?= $user_id ?>">
                                <input type="hidden" name="tutor_phone" value="<?= isset($tutor['phone']) ? $tutor['phone'] : '' ?>">
                                <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold request-button" style="background: linear-gradient(135deg, #1E3A8A, #0F1C4D); border: none; transition: all 0.3s ease;">
                                    <i class="fas fa-paper-plane me-2"></i>Send Request
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo '<div class="col-12 text-center py-4 py-md-5">
                    <div class="alert alert-info no-tutors-alert" style="background: linear-gradient(135deg, #e3f2fd, #bbdefb); border: none; border-radius: 15px; padding: 1.5rem; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
                        <i class="fas fa-info-circle me-2"></i>No tutors found for the selected criteria. Please try different search options.
                    </div>
                  </div>';
        }
        ?>
    </div>
</div>

<!-- How It Works Section -->
<div class="py-4 py-md-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-4 mb-md-5">How It Works</h2>
        <div class="row g-4">
            <div class="col-12 col-md-4">
                <div class="text-center p-3 p-md-4">
                    <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                        <h3 class="mb-0">1</h3>
                    </div>
                    <h4>Search & Find</h4>
                    <p class="text-muted small">Browse through our verified tutors or use our search feature to find the perfect match.</p>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="text-center p-3 p-md-4">
                    <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                        <h3 class="mb-0">2</h3>
                    </div>
                    <h4>Send Request</h4>
                    <p class="text-muted small">Contact your preferred tutor and discuss your requirements.</p>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="text-center p-3 p-md-4">
                    <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                        <h3 class="mb-0">3</h3>
                    </div>
                    <h4>Start Learning</h4>
                    <p class="text-muted small">Begin your learning journey with personalized attention from your tutor.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Testimonials Section -->
<div class="py-4 py-md-5">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 mb-md-5">
            <h2 class="text-center mb-3 mb-md-0">What Our Students Say</h2>
            <div class="d-flex gap-2">
            <?php
// Start session at the top of the file if not already done

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, send to login page
    $link = 'login.php?msg=Please login to share your experience';
} else {
    // If logged in, allow access to add_testimonial.php
    $link = 'add_testimonial.php';
}
?>

<a href="<?php echo $link; ?>" class="btn btn-primary">
    <i class="fas fa-pen me-2"></i>Share Your Experience
</a>

                <a href="testimonials.php" class="btn btn-outline-primary">
                    <i class="fas fa-list me-2"></i>View All
                </a>
            </div>
        </div>
        <div class="row g-4">
            <?php
            // Get page number from URL, default to 1
            $page = isset($_GET['testimonial_page']) ? (int)$_GET['testimonial_page'] : 1;
            $per_page = 3;
            $offset = ($page - 1) * $per_page;

            $testimonials = $conn->query("
                SELECT t.*, u.name as student_name 
                FROM testimonials t 
                JOIN users u ON t.student_id = u.id 
                WHERE t.status = 'approved' 
                ORDER BY t.created_at DESC 
                LIMIT $offset, $per_page
            ");
            
            if ($testimonials->num_rows > 0) {
                while ($testimonial = $testimonials->fetch_assoc()) {
                    ?>
                    <div class="col-12 col-md-4">
                        <div class="card h-100 border-0 shadow-sm p-3 p-md-4 hover-shadow">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5 class="mb-0 small"><?= htmlspecialchars($testimonial['student_name']) ?></h5>
                                    <div class="text-warning">
                                        <?php
                                        for ($i = 1; $i <= 5; $i++) {
                                            echo $i <= $testimonial['rating'] ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <p class="text-muted small"><?= htmlspecialchars($testimonial['content']) ?></p>
                            <small class="text-muted">
                                <i class="far fa-clock me-1"></i>
                                <?= date('F j, Y', strtotime($testimonial['created_at'])) ?>
                            </small>
                        </div>
                    </div>
                    <?php
                }
            } else {
                // Show placeholder testimonials if none exist
                $placeholder_testimonials = [
                    [
                        'student_name' => 'Sarah Johnson',
                        'rating' => 5,
                        'content' => 'The platform helped me find an excellent math tutor. My grades have improved significantly!',
                        'created_at' => date('Y-m-d H:i:s')
                    ],
                    [
                        'student_name' => 'Michael Chen',
                        'rating' => 5,
                        'content' => 'Great experience! The tutor was very professional and helped me understand complex concepts easily.',
                        'created_at' => date('Y-m-d H:i:s')
                    ],
                    [
                        'student_name' => 'Emily Rodriguez',
                        'rating' => 5,
                        'content' => 'I found the perfect tutor for my child. The learning process has been smooth and effective.',
                        'created_at' => date('Y-m-d H:i:s')
                    ]
                ];
                
                foreach ($placeholder_testimonials as $testimonial) {
                    ?>
                    <div class="col-12 col-md-4">
                        <div class="card h-100 border-0 shadow-sm p-3 p-md-4 hover-shadow">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5 class="mb-0 small"><?= htmlspecialchars($testimonial['student_name']) ?></h5>
                                    <div class="text-warning">
                                        <?php
                                        for ($i = 1; $i <= 5; $i++) {
                                            echo $i <= $testimonial['rating'] ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <p class="text-muted small"><?= htmlspecialchars($testimonial['content']) ?></p>
                            <small class="text-muted">
                                <i class="far fa-clock me-1"></i>
                                <?= date('F j, Y', strtotime($testimonial['created_at'])) ?>
                            </small>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>

        <!-- Testimonials Pagination -->
        <?php
        $total_testimonials = $conn->query("SELECT COUNT(*) as count FROM testimonials WHERE status = 'approved'")->fetch_assoc()['count'];
        $total_pages = ceil($total_testimonials / $per_page);
        
        if ($total_pages > 1):
        ?>
        <nav aria-label="Testimonials pagination" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?testimonial_page=<?= $page - 1 ?>#testimonials">Previous</a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?testimonial_page=<?= $i ?>#testimonials"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?testimonial_page=<?= $page + 1 ?>#testimonials">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>

<!-- Call to Action Section -->
<div class="py-4 py-md-5 bg-primary text-white">
    <div class="container text-center">
        <h2 class="mb-3 mb-md-4">Ready to Find Your Perfect Tutor?</h2>
        <p class="lead mb-3 mb-md-4">Join thousands of students who have found their ideal learning partner.</p>
        <a href="#" onclick="window.scrollTo({top: 0, behavior: 'smooth'}); return false;" class="btn btn-light btn-lg px-4 px-md-5 get-started-button">
            <i class="fas fa-search me-2"></i>Get Started
        </a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check if we have tutors to show (form was submitted)
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        // Scroll to tutors section with smooth animation
        const tutorsSection = document.getElementById('tutors-section');
        if (tutorsSection) {
            tutorsSection.scrollIntoView({ behavior: 'smooth' });
        }
    <?php endif; ?>

    // Handle form submission for non-logged-in users
    const searchForm = document.querySelector('form');
    const searchButton = document.querySelector('button[type="submit"]');
    
    searchForm.addEventListener('submit', function(e) {
        <?php if (!isset($_SESSION['user_id'])): ?>
            e.preventDefault();
            searchButton.innerHTML = '<div class="spinner-border spinner-border-sm me-2" role="status"></div>Redirecting...';
            setTimeout(() => {
                window.location.href = 'login.php?msg=Please login or signup to search for a tutor';
            }, 1000);
        <?php endif; ?>
    });

    // Handle scroll to search section
    const getStartedButton = document.querySelector('.get-started-button');
    getStartedButton.addEventListener('click', function(e) {
        e.preventDefault();
        const searchSection = document.querySelector('.py-5');
        if (searchSection) {
            searchSection.scrollIntoView({ behavior: 'smooth' });
        }
    });
});
</script>

<style>
/* Global Styles */
:root {
    --primary-color: #1E3A8A;
    --secondary-color: #0F1C4D;
    --accent-color: #4F46E5;
    --text-color: #1F2937;
    --light-bg: #F9FAFB;
    --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --hover-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --gradient-primary: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    --gradient-accent: linear-gradient(135deg, var(--accent-color), var(--primary-color));
}

body {
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    color: var(--text-color);
    background-color: var(--light-bg);
    line-height: 1.7;
}

/* Hero Section Enhancement */
.py-4.py-md-5[style*="linear-gradient"] {
    background: var(--gradient-primary);
    position: relative;
    overflow: hidden;
    min-height: 500px;
    display: flex;
    align-items: center;
}

.py-4.py-md-5[style*="linear-gradient"]::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    opacity: 0.1;
    animation: patternMove 20s linear infinite;
}

@keyframes patternMove {
    0% { background-position: 0 0; }
    100% { background-position: 100px 100px; }
}

/* Search Form Enhancement */
.search-form {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 1rem;
    padding: 2rem;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.search-form:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
}

.form-select, .form-control {
    border: 2px solid #E5E7EB;
    border-radius: 0.75rem;
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
    background-color: rgba(255, 255, 255, 0.9);
}

.form-select:focus, .form-control:focus {
    border-color: var(--accent-color);
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    background-color: #fff;
}

/* Card Enhancements */
.tutor-card {
    position: relative;
    overflow: hidden;
    border: none;
    border-radius: 1rem;
    background: white;
    box-shadow: var(--card-shadow);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.tutor-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
}

.tutor-card::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: var(--gradient-accent);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.tutor-card:hover::after {
    opacity: 1;
}

.tutor-image-container {
    position: relative;
    margin: 0 auto 1.5rem;
}

.tutor-image {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 4px solid white;
    box-shadow: var(--card-shadow);
    transition: transform 0.3s ease;
    object-fit: cover;
}

.tutor-card:hover .tutor-image {
    transform: scale(1.05);
}

/* Button Styles */
.btn {
    border-radius: 0.75rem;
    padding: 0.75rem 1.5rem;
    font-weight: 600;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-primary {
    background: var(--gradient-primary);
    border: none;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2);
}

.btn-primary::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0));
    opacity: 0;
    transition: opacity 0.3s ease;
}

.btn-primary:hover::after {
    opacity: 1;
}

/* Quick Actions */
.quick-actions {
    margin-top: 2rem;
}

.quick-action-card {
    background: white;
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    text-decoration: none;
    color: var(--text-color);
    display: block;
}

.quick-action-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
    color: var(--text-color);
}

.quick-action-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1rem;
    background: var(--gradient-primary);
    color: white;
    font-size: 1.5rem;
}

/* Testimonials Enhancement */
.testimonial-card {
    background: white;
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.testimonial-card:hover {
    transform: translateY(-3px);
    box-shadow: var(--hover-shadow);
}

.testimonial-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid white;
    box-shadow: var(--card-shadow);
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .py-4.py-md-5[style*="linear-gradient"] {
        min-height: 400px;
    }

    .search-form {
        padding: 1.5rem;
    }

    .display-4 {
        font-size: 2.25rem;
    }
    
    .lead {
        font-size: 1.125rem;
    }
    
    .tutor-image {
        width: 100px;
        height: 100px;
    }
    
    .card-body {
        padding: 1.25rem;
    }

    .quick-action-card {
        margin-bottom: 1rem;
    }
}

@media (max-width: 576px) {
    .py-4.py-md-5[style*="linear-gradient"] {
        min-height: 350px;
    }

    .search-form {
        padding: 1rem;
    }

    .display-4 {
        font-size: 2rem;
    }
    
    .lead {
        font-size: 1rem;
    }
    
    .tutor-image {
        width: 90px;
        height: 90px;
    }
    
    .btn {
        padding: 0.625rem 1.25rem;
    }
}

/* Animation Classes */
.hover-lift {
    transition: transform 0.3s ease;
}

.hover-lift:hover {
    transform: translateY(-5px);
}

/* Custom Scrollbar */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
    background: var(--primary-color);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--secondary-color);
}
</style>

<!-- Add Quick Actions Section after Hero -->
<div class="container py-4">
    <div class="row g-4 quick-actions">
        <div class="col-md-3">
            <a href="tutors_by_subject.php" class="quick-action-card">
                <div class="quick-action-icon">
                    <i class="fas fa-book"></i>
                </div>
                <h5>Browse by Subject</h5>
                <p class="text-muted mb-0">Find tutors specialized in your subject</p>
            </a>
        </div>
        <div class="col-md-3">
            <a href="qna.php" class="quick-action-card">
                <div class="quick-action-icon">
                    <i class="fas fa-question-circle"></i>
                </div>
                <h5>Q&A Forum</h5>
                <p class="text-muted mb-0">Get help from our community</p>
            </a>
        </div>
        <div class="col-md-3">
            <a href="testimonials.php" class="quick-action-card">
                <div class="quick-action-icon">
                    <i class="fas fa-star"></i>
                </div>
                <h5>Success Stories</h5>
                <p class="text-muted mb-0">Read student testimonials</p>
            </a>
        </div>
        <div class="col-md-3">
            <a href="tutor_register.php" class="quick-action-card">
                <div class="quick-action-icon">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <h5>Become a Tutor</h5>
                <p class="text-muted mb-0">Join our teaching community</p>
            </a>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
