<?php

$servername = "localhost";
$username = "root"; // Your MySQL username
$password = "mysql"; // Your MySQL password
$dbname = "home_tutor_db"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
