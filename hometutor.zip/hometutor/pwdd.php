<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Password Hasher</title>
</head>
<body>
    <h2>PHP Password Hasher</h2>
    <form method="post">
        <label for="password">1234567890</label>
        <input type="password" name="password" id="password" required>
        <button type="submit">Hash Password</button>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
        $password = $_POST['password'];
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        echo "<h3>Hashed Password:</h3>";
        echo "<textarea rows='3' cols='80' readonly>$hashedPassword</textarea>";
    }
    ?>
</body>
</html>