<?php
session_start();
include 'db.php';
include 'tutor_header.php';

if (!isset($_GET['question_id']) || !is_numeric($_GET['question_id'])) {
    die("Invalid question ID.");
}

$question_id = $_GET['question_id'];
$user_id = $_SESSION['user_id'] ?? null;


// Fetch the question details
$query = "SELECT * FROM questions WHERE id = '$question_id'";
$result = mysqli_query($conn, $query);
$question = mysqli_fetch_assoc($result);
?>

<style>
    .answer-container {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 15px;
        margin-left: 20px;
    }
    .vote-buttons {
        margin-top: 10px;
    }
    .vote-buttons a {
        text-decoration: none;
        padding: 4px 8px;
        border-radius: 3px;
        margin-right: 8px;
        font-size: 0.9em;
    }
    .like-button {
        background-color: #4CAF50;
        color: white;
    }
    .dislike-button {
        background-color: #f44336;
        color: white;
    }
    .vote-count {
        font-weight: bold;
        margin-right: 15px;
    }
    .answer-image {
        max-width: 100%;
        height: auto;
        margin-top: 10px;
        border-radius: 4px;
    }
</style>

<div class="container mt-4">
    <div class="card mb-4">
        <div class="card-body">
            <h2>Question Details</h2>
            <p><strong>Question:</strong> <?= htmlspecialchars($question['question']) ?></p>
            <p><strong>Subject:</strong> <?= htmlspecialchars($question['subject']) ?></p>
        </div>
    </div>

    <h3>Answers</h3>
    <?php
    // Fetch all answers for the question
    $answers = mysqli_query($conn, "SELECT a.*, u.name FROM answers a JOIN users u ON a.user_id = u.id WHERE question_id = '$question_id' ORDER BY a.created_at ASC");

    while ($a = mysqli_fetch_assoc($answers)) {
        // Check if the user has already voted on this answer
        $answer_id = $a['id'];
        $vote_check = mysqli_query($conn, "SELECT * FROM answer_votes WHERE answer_id = '$answer_id' AND user_id = '$user_id'");

        $user_vote = mysqli_fetch_assoc($vote_check);
        $user_liked = false;
        $user_disliked = false;

        if ($user_vote) {
            if ($user_vote['vote_type'] == 'like') {
                $user_liked = true;
            } elseif ($user_vote['vote_type'] == 'dislike') {
                $user_disliked = true;
            }
        }

        // Get likes and dislikes count
        $likes_query = mysqli_query($conn, "SELECT COUNT(*) AS likes FROM answer_votes WHERE answer_id = '$answer_id' AND vote_type = 'like'");
        $dislikes_query = mysqli_query($conn, "SELECT COUNT(*) AS dislikes FROM answer_votes WHERE answer_id = '$answer_id' AND vote_type = 'dislike'");
        $likes = mysqli_fetch_assoc($likes_query)['likes'];
        $dislikes = mysqli_fetch_assoc($dislikes_query)['dislikes'];
    ?>
        <div class="answer-container">
            <div class="answer-content">
                <strong>Answer by <?= htmlspecialchars($a['name']) ?>:</strong><br>
                <?= nl2br(htmlspecialchars($a['answer'])) ?>
                <?php if ($a['image']): ?>
                    <img src="<?= htmlspecialchars($a['image']) ?>" class="answer-image" alt="Answer image">
                <?php endif; ?>
            </div>
            
            <div class="text-muted small">
                <em>Posted on: <?= $a['created_at'] ?></em>
            </div>

            <div class="vote-buttons">
                <span class="vote-count">👍 <?= $likes ?></span>
                <span class="vote-count">👎 <?= $dislikes ?></span>
                
                <?php if (!$user_liked && !$user_disliked): ?>
                    <a href="vote.php?action=like&answer_id=<?= $a['id'] ?>" class="like-button">Like</a>
                    <a href="vote.php?action=dislike&answer_id=<?= $a['id'] ?>" class="dislike-button">Dislike</a>
                <?php elseif ($user_liked): ?>
                    <span style="color: #4CAF50;">You liked this answer</span>
                <?php elseif ($user_disliked): ?>
                    <span style="color: #f44336;">You disliked this answer</span>
                <?php endif; ?>
            </div>
        </div>
    <?php } ?>

    <a href="tutor_qna.php" class="btn btn-primary mt-3">Back to Q&A Section</a>
</div>
