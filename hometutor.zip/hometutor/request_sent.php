<?php
session_start();
include("header.php"); // Include your header

?>
<div class="container py-5">
    <h2 class="text-center">Request Sent!</h2>
    <p class="text-center">Your request has been sent to the tutor. You will be notified when they respond.</p>
    <div class="text-center">
        <a href="index.php" class="btn btn-primary">Back to Home</a>
    </div>
</div>

<?php
include("footer.php"); // Include your footer
?>
