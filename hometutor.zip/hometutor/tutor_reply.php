<?php
session_start();
include 'db.php';
include 'tutor_header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You need to be logged in to post an answer.");
}

// Validate the question ID in the URL
if (!isset($_GET['question_id']) || !is_numeric($_GET['question_id'])) {
    die("Invalid question ID. Please check the URL.");
}

$question_id = $_GET['question_id'];
$user_id = $_SESSION['user_id'];

// Fetch the question details
$query = "SELECT * FROM questions WHERE id = '$question_id'";
$result = mysqli_query($conn, $query);

// Check if the question exists
if (mysqli_num_rows($result) == 0) {
    die("Question not found.");
}

$question = mysqli_fetch_assoc($result);

// Handle form submission after form is loaded
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $answer = mysqli_real_escape_string($conn, $_POST['answer']);
    $imagePath = null;

    // Handle image upload (if any)
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "img/questions/";  // Folder where images will be uploaded
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);  // Create the directory if it doesn't exist
        }

        $imageName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;

        // Move the uploaded image to the server's file system
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $imagePath = $targetFile;
        } else {
            die("There was an error uploading the image.");
        }
    }

    // Insert answer into the database
    $insertQuery = "INSERT INTO answers (question_id, user_id, answer, image) VALUES ('$question_id', '$user_id', '$answer', '$imagePath')";

    if (mysqli_query($conn, $insertQuery)) {
        // Redirect to the Q&A page after successful insertion
        header("Location: tutor_qna.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm" style="border: none; border-radius: 15px;">
                <div class="card-body p-4">
                    <h2 class="mb-4" style="color: #0F1C4D; font-weight: 700;">Submit Your Answer</h2>
                    
                    <div class="mb-4 p-3" style="background-color: #f8f9fa; border-radius: 10px;">
                        <p class="mb-2"><strong style="color: #1E3A8A;">Question:</strong> <?= htmlspecialchars($question['question']) ?></p>
                        <p class="mb-0"><strong style="color: #1E3A8A;">Subject:</strong> <?= htmlspecialchars($question['subject']) ?></p>
                    </div>

                    <form method="POST" action="tutor-submit-answer.php?question_id=<?= $question['id'] ?>" enctype="multipart/form-data">
                        <div class="mb-4">
                            <textarea name="answer" class="form-control" placeholder="Your answer..." required 
                                style="height: 200px; border-radius: 10px; border: 1px solid #dee2e6; padding: 15px; resize: vertical;"></textarea>
                        </div>
                        
                        <div class="mb-4">
                            <label for="image" class="form-label" style="color: #1E3A8A; font-weight: 500;">
                                <i class="fas fa-image me-2"></i>Attach Image (Optional)
                            </label>
                            <input type="file" name="image" class="form-control" id="image" 
                                style="border-radius: 10px; border: 1px solid #dee2e6;">
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 py-3" 
                            style="background: linear-gradient(90deg, #0F1C4D, #1E3A8A); border: none; border-radius: 10px; font-weight: 500;">
                            <i class="fas fa-paper-plane me-2"></i>Post Answer
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.form-control:focus {
    border-color: #1E3A8A;
    box-shadow: 0 0 0 0.2rem rgba(30, 58, 138, 0.25);
}

.btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.card {
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-2px);
}
</style>

<?php include 'footer.php'; ?>
