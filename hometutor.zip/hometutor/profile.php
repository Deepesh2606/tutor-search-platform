<?php
session_start();
include('db.php');
include('header.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    $sql = "UPDATE users SET name='$name', email='$email', phone='$phone', 
            address='$address', latitude='$latitude', longitude='$longitude' 
            WHERE id='$user_id'";

    if ($conn->query($sql) === TRUE) {
        $success_message = "Profile updated successfully!";
    } else {
        $error_message = "Error updating profile: " . $conn->error;
    }
}

// Get user data
$sql = "SELECT * FROM users WHERE id='$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    #map {
        height: 300px;
        width: 100%;
    }
    </style>

</head>

<body>
    <div class="container py-5">
        <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card shadow">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Edit Profile</h2>
                        <form method="POST" id="profileForm">
                            <div class="form-group mb-3">
                                <label class="form-label">
                                    <i class="fas fa-user me-2"></i>Full Name
                                </label>
                                <input type="text" name="name" class="form-control"
                                    value="<?php echo htmlspecialchars($user['name']); ?>" required>
                            </div>

                            <div class="form-group mb-3">
                                <label class="form-label">
                                    <i class="fas fa-envelope me-2"></i>Email Address
                                </label>
                                <input type="email" name="email" class="form-control"
                                    value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>

                            <div class="form-group mb-3">
                                <label class="form-label">
                                    <i class="fas fa-phone me-2"></i>Phone Number
                                </label>
                                <input type="text" name="phone" class="form-control"
                                    value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                            </div>

                            <div class="form-group mb-3">
                                <label class="form-label">
                                    <i class="fas fa-map-marker-alt me-2"></i>Search Address
                                </label>
                                <input type="text" id="autocomplete" placeholder="Type your home address"
                                    class="form-control">
                            </div>

                            <div class="form-group mb-3">
                                <label class="form-label">
                                    <i class="fas fa-home me-2"></i>Selected Address
                                </label>
                                <input type="text" name="address" id="address" class="form-control"
                                    value="<?php echo htmlspecialchars($user['address']); ?>" required>
                                <input type="hidden" name="latitude" id="latitude"
                                    value="<?php echo htmlspecialchars($user['latitude']); ?>">
                                <input type="hidden" name="longitude" id="longitude"
                                    value="<?php echo htmlspecialchars($user['longitude']); ?>">
                            </div>

                            <div id="map" class="mb-4 rounded-3"></div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Update Profile
                                </button>
                                <a href="logout.php" class="btn btn-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYqMA1rU_SMUIopL228VhSWtdkJ5Dvxdc&libraries=places">
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYqMA1rU_SMUIopL228VhSWtdkJ5Dvxdc&libraries=places">
    </script>
    <script>
    let map, marker, autocomplete;

    function initMap() {
        const lat = parseFloat(document.getElementById('latitude').value) || 30.900965;
        const lng = parseFloat(document.getElementById('longitude').value) || 75.857277;
        const defaultLatLng = {
            lat,
            lng
        };

        map = new google.maps.Map(document.getElementById("map"), {
            center: defaultLatLng,
            zoom: 14,
        });

        marker = new google.maps.Marker({
            map: map,
            position: defaultLatLng,
            draggable: true,
        });

        autocomplete = new google.maps.places.Autocomplete(
            document.getElementById('autocomplete'), {
                types: ['geocode']
            }
        );

        autocomplete.addListener('place_changed', () => {
            const place = autocomplete.getPlace();
            if (!place.geometry) return;

            map.setCenter(place.geometry.location);
            marker.setPosition(place.geometry.location);

            document.getElementById('latitude').value = place.geometry.location.lat();
            document.getElementById('longitude').value = place.geometry.location.lng();
            document.getElementById('address').value = place.formatted_address;
        });

        marker.addListener('dragend', () => {
            const pos = marker.getPosition();
            document.getElementById('latitude').value = pos.lat();
            document.getElementById('longitude').value = pos.lng();

            const geocoder = new google.maps.Geocoder();
            geocoder.geocode({
                location: pos
            }, (results, status) => {
                if (status === "OK" && results[0]) {
                    document.getElementById('address').value = results[0].formatted_address;
                }
            });
        });
    }

    window.onload = initMap;

    // Validation for empty location before submission
    document.getElementById("profileForm").addEventListener("submit", function(e) {
        const address = document.getElementById("address").value.trim();
        const lat = document.getElementById("latitude").value.trim();
        const lng = document.getElementById("longitude").value.trim();

        if (!address || !lat || !lng) {
            e.preventDefault();
            alert("📍 Please select your address using the map or the search bar.");
        }
    });
    </script>

</body>

</html>