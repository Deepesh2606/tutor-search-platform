<?php
session_start();
include('db.php');
include('header.php');

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    $_SESSION['message'] = "Please sign in to access this page";
    header("Location: login.php");
    exit();
}

$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle testimonial deletion
    if (isset($_POST['delete_testimonial'])) {
        $testimonial_id = (int)$_POST['testimonial_id'];
        if ($testimonial_id > 0) {
            $delete_sql = "DELETE FROM testimonials WHERE id = ?";
            $stmt = $conn->prepare($delete_sql);
            $stmt->bind_param("i", $testimonial_id);
            
            if ($stmt->execute()) {
                $message = "✅ Testimonial deleted successfully!";
            } else {
                $message = "❌ Error deleting testimonial: " . $conn->error;
            }
            $stmt->close();
        } else {
            $message = "❌ Invalid testimonial ID";
        }
    }
    // Handle status update
    elseif (isset($_POST['update_status'])) {
        $testimonial_id = (int)$_POST['testimonial_id'];
        $new_status = $_POST['status'];
        
        if ($testimonial_id > 0 && in_array($new_status, ['pending', 'approved', 'rejected'])) {
            $update_sql = "UPDATE testimonials SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("si", $new_status, $testimonial_id);
            
            if ($stmt->execute()) {
                $message = "✅ Testimonial status updated successfully!";
            } else {
                $message = "❌ Error updating testimonial status: " . $conn->error;
            }
            $stmt->close();
        } else {
            $message = "❌ Invalid status update request";
        }
    }
}

// Fetch all testimonials with student names
$testimonials_query = "SELECT t.*, u.name as student_name 
                      FROM testimonials t 
                      JOIN users u ON t.student_id = u.id 
                      ORDER BY t.created_at DESC";
$testimonials_result = $conn->query($testimonials_query);

if (!$testimonials_result) {
    die("Query Error: " . $conn->error);
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Manage Testimonials</h4>
                    <a href="index.php" class="btn btn-light btn-sm">
                        <i class="fas fa-home"></i> Go to Home
                    </a>
                </div>
                <div class="card-body">
                    <?php if (!empty($message)): ?>
                        <div class="alert <?php echo strpos($message, '✅') !== false ? 'alert-success' : 'alert-danger'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Student Name</th>
                                    <th>Content</th>
                                    <th>Rating</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($testimonials_result->num_rows > 0): ?>
                                    <?php while ($testimonial = $testimonials_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $testimonial['id']; ?></td>
                                            <td><?php echo htmlspecialchars($testimonial['student_name']); ?></td>
                                            <td><?php echo htmlspecialchars($testimonial['content']); ?></td>
                                            <td>
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i class="fas fa-star <?php echo $i <= $testimonial['rating'] ? 'text-warning' : 'text-secondary'; ?>"></i>
                                                <?php endfor; ?>
                                            </td>
                                            <td>
                                                <form method="POST" action="" style="display: inline;">
                                                    <input type="hidden" name="testimonial_id" value="<?php echo $testimonial['id']; ?>">
                                                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                                        <option value="pending" <?php echo $testimonial['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                        <option value="approved" <?php echo $testimonial['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                                        <option value="rejected" <?php echo $testimonial['status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                                    </select>
                                                    <input type="hidden" name="update_status" value="1">
                                                </form>
                                            </td>
                                            <td><?php echo date('M d, Y H:i', strtotime($testimonial['created_at'])); ?></td>
                                            <td>
                                                <form method="POST" action="" style="display: inline;">
                                                    <input type="hidden" name="testimonial_id" value="<?php echo $testimonial['id']; ?>">
                                                    <button type="submit" name="delete_testimonial" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this testimonial?')">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No testimonials found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
