<?php
session_start();
include 'db.php';

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Get filter parameters
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Build query
$query = "SELECT * FROM users WHERE role = 'student'";
$params = [];
$types = "";

if (!empty($search_query)) {
    $query .= " AND (name LIKE ? OR email LIKE ?)";
    $search_param = "%$search_query%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

$query .= " ORDER BY created_at DESC";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$student_result = $stmt->get_result();

// Get total students count
$total_students = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'student'")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Students Management</h1>
        <div class="d-flex gap-2">
            <form class="d-flex" method="GET">
                <input type="text" name="search" class="form-control me-2" placeholder="Search students..." value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-1"></i>Search
                </button>
            </form>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card p-3">
                <h6 class="card-title">Total Students</h6>
                <p class="card-value"><?php echo $total_students; ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3">
                <h6 class="card-title">Active Students</h6>
                <p class="card-value"><?php echo $total_students; ?></p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3">
                <h6 class="card-title">Inactive Students</h6>
                <p class="card-value">0</p>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($student_result->num_rows > 0) {
                            while ($student = $student_result->fetch_assoc()) {
                                echo "<tr>
                                        <td>" . $student['id'] . "</td>
                                        <td>" . $student['name'] . "</td>
                                        <td>" . $student['email'] . "</td>
                                        <td>" . ($student['phone'] ?? 'N/A') . "</td>
                                        <td><span class='status-badge status-active'>Active</span></td>
                                        <td>" . date('M d, Y', strtotime($student['created_at'])) . "</td>
                                        <td>
                                            <div class='d-flex gap-2'>
                                             
                                                <button class='btn btn-danger action-btn' onclick='confirmDelete(" . $student['id'] . ")'>
                                                    <i class='fas fa-trash me-1'></i>Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>No students found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Action</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="modalMessage"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmAction">Confirm</button>
            </div>
        </div>
    </div>
</div>

<!-- Student Details Modal -->
<div class="modal fade" id="studentDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Student Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="studentDetails">
                <!-- Student details will be loaded here -->
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentId = 0;

function confirmDelete(id) {
    currentId = id;
    
    const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));
    const message = document.getElementById('modalMessage');
    const confirmBtn = document.getElementById('confirmAction');
    
    message.textContent = 'Are you sure you want to delete this student? This action cannot be undone.';
    confirmBtn.className = 'btn btn-danger';
    modal.show();
}

function viewStudent(id) {
    const modal = new bootstrap.Modal(document.getElementById('studentDetailsModal'));
    const detailsDiv = document.getElementById('studentDetails');
    
    // Show loading state
    detailsDiv.innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading student details...</div>';
    modal.show();
    
    // Fetch student details
    fetch(`get_student_details.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                detailsDiv.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
                return;
            }
            
            detailsDiv.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Name:</strong> ${data.name}</p>
                        <p><strong>Email:</strong> ${data.email}</p>
                        <p><strong>Phone:</strong> ${data.phone}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-${data.status}">${data.status}</span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Created At:</strong> ${data.created_at}</p>
                        ${data.profile ? `
                            <p><strong>Grade Level:</strong> ${data.profile.grade_level || 'N/A'}</p>
                            <p><strong>Subjects:</strong> ${data.profile.subjects || 'N/A'}</p>
                            <p><strong>Address:</strong> ${data.profile.address || 'N/A'}</p>
                        ` : ''}
                    </div>
                </div>
            `;
        })
        .catch(error => {
            detailsDiv.innerHTML = `<div class="alert alert-danger">Error loading student details: ${error.message}</div>`;
        });
}

document.getElementById('confirmAction').addEventListener('click', function() {
    // In a real application, you would make an AJAX call to delete the student
    // fetch(`delete_student.php?id=${currentId}`, { method: 'POST' })
    //     .then(response => response.json())
    //     .then(data => {
    //         if (data.success) {
    //             window.location.reload();
    //         } else {
    //             alert('Error deleting student');
    //         }
    //     });
    
    // For demo purposes, we'll just reload the page
    window.location.reload();
});
</script>

</body>
</html> 