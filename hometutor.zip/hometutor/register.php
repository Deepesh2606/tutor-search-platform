<?php
// db.php — Include DB connection
include('db.php');
include('header.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name      = $_POST['name'];
    $email     = $_POST['email'];
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $address   = $_POST['address'];
    $latitude  = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $phone     = $_POST['phone']; // New phone column

    // Insert user into the database
    $sql = "INSERT INTO users (name, email, password, address, latitude, longitude, phone) 
            VALUES ('$name', '$email', '$password', '$address', '$latitude', '$longitude', '$phone')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert alert-success'>✅ Registration successful!</div>";
    } else {
        echo "<div class='alert alert-danger'>❌ Error: " . $conn->error . "</div>";
    }
}
?>
<?php
if (isset($_GET['msg'])) {
    echo "<div class='alert alert-info text-center mt-3'>" . htmlspecialchars($_GET['msg']) . "</div>";
}
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="text-center mb-4">
            <i class="fas fa-user-plus fa-3x mb-3" style="color: #1E3A8A;"></i>
            <h2 class="auth-title">Student Registration</h2>
            <p class="text-muted">Create your account to find the perfect tutor</p>
        </div>

        <form method="POST" id="registerForm" class="auth-form">
            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-user me-2"></i>Full Name
                </label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-envelope me-2"></i>Email Address
                </label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-lock me-2"></i>Password
                </label>
                <div class="input-group">
                    <input type="password" name="password" class="form-control" id="password" required>
                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-phone me-2"></i>Phone Number
                </label>
                <input type="text" name="phone" class="form-control" required value="+91">
                <small class="form-text text-muted">This will be used by tutors to contact you directly.</small>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-map-marker-alt me-2"></i>Search Address
                </label>
                <input type="text" id="autocomplete" placeholder="Type your home address" class="form-control">
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-home me-2"></i>Selected Address
                </label>
                <input type="text" name="address" id="address" class="form-control" readonly required>
                <input type="hidden" name="latitude" id="latitude">
                <input type="hidden" name="longitude" id="longitude">
            </div>

            <div id="map" class="mb-4 rounded-3"></div>

            <button type="submit" class="btn btn-primary auth-btn">
                <i class="fas fa-user-plus me-2"></i>Register
            </button>

            <div class="form-error text-center mt-3" id="locationError"></div>
        </form>

        <div class="auth-footer text-center mt-4">
            <p class="mb-0">Already have an account? 
                <a href="login.php" class="auth-link">
                    <i class="fas fa-sign-in-alt me-1"></i>Login here
                </a>
            </p>
        </div>
    </div>
</div>

<style>
.auth-container {
    min-height: calc(100vh - 76px);
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 1rem;
}

.auth-card {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 500px;
    margin: 1rem;
}

.auth-title {
    color: #1E3A8A;
    font-weight: 700;
    margin-bottom: 0.5rem;
    font-size: 1.75rem;
}

.form-group {
    margin-bottom: 1.25rem;
}

.form-label {
    color: #495057;
    font-weight: 500;
    margin-bottom: 0.5rem;
    display: block;
    font-size: 1rem;
}

.form-control {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
    font-size: 1rem;
    height: auto;
}

.form-control:focus {
    border-color: #1E3A8A;
    box-shadow: 0 0 0 0.2rem rgba(30, 58, 138, 0.15);
}

.auth-btn {
    background: linear-gradient(135deg, #1E3A8A, #0F1C4D);
    border: none;
    border-radius: 8px;
    padding: 0.75rem;
    font-weight: 600;
    width: 100%;
    transition: all 0.3s ease;
    font-size: 1rem;
    height: auto;
}

.auth-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 58, 138, 0.3);
}

.auth-link {
    color: #1E3A8A;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
    font-size: 1rem;
}

.auth-link:hover {
    color: #0F1C4D;
    text-decoration: underline;
}

.toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1055;
    width: auto;
    max-width: 90%;
    display: flex;
    justify-content: flex-end;
    pointer-events: none;
}

.toast {
    background: #1E3A8A;
    color: white;
    border-radius: 8px;
    padding: 1rem 1.25rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    animation: slideIn 0.4s ease forwards;
    pointer-events: auto;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(100%);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

#map {
    height: 200px;
    width: 100%;
    border-radius: 8px;
    margin-top: 0.5rem;
}

.input-group {
    position: relative;
}

.input-group .btn {
    border-color: #e9ecef;
    background: transparent;
    transition: all 0.3s ease;
    padding: 0.75rem;
}

.input-group .btn:hover {
    background: rgba(30, 58, 138, 0.1);
    border-color: #1E3A8A;
}

.input-group .btn i {
    color: #1E3A8A;
    font-size: 1rem;
}

@media (max-width: 576px) {
    .auth-container {
        padding: 0.5rem;
    }
    
    .auth-card {
        padding: 1.5rem;
        margin: 0.5rem;
    }
    
    .auth-title {
        font-size: 1.5rem;
    }
    
    .form-control {
        padding: 0.75rem;
        font-size: 16px; /* Prevents zoom on iOS */
    }
    
    .auth-btn {
        padding: 0.75rem;
        font-size: 1rem;
    }
    
    .toast-container {
        right: 10px;
        left: 10px;
        top: 15px;
        justify-content: center;
    }

    .toast {
        width: 100%;
        text-align: center;
        padding: 0.75rem 1rem;
    }
    
    .input-group .btn {
        padding: 0.75rem;
    }
    
    #map {
        height: 150px;
    }
}

@media (max-width: 360px) {
    .auth-card {
        padding: 1.25rem;
    }
    
    .auth-title {
        font-size: 1.25rem;
    }
    
    .form-control {
        padding: 0.5rem;
    }
    
    .auth-btn {
        padding: 0.5rem;
    }
    
    #map {
        height: 120px;
    }
}
</style>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYqMA1rU_SMUIopL228VhSWtdkJ5Dvxdc&libraries=places"></script>
<script>
let map, marker, autocomplete;

function initMap() {
    const defaultLatLng = { lat: 30.900965, lng: 75.857277 };

    map = new google.maps.Map(document.getElementById("map"), {
        center: defaultLatLng,
        zoom: 14,
    });

    marker = new google.maps.Marker({
        map: map,
        position: defaultLatLng,
        draggable: true,
    });

    autocomplete = new google.maps.places.Autocomplete(
        document.getElementById('autocomplete'),
        { types: ['geocode'] }
    );

    autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        if (!place.geometry) return;

        map.setCenter(place.geometry.location);
        marker.setPosition(place.geometry.location);

        document.getElementById('latitude').value = place.geometry.location.lat();
        document.getElementById('longitude').value = place.geometry.location.lng();
        document.getElementById('address').value = place.formatted_address;
    });

    marker.addListener('dragend', () => {
        const pos = marker.getPosition();
        document.getElementById('latitude').value = pos.lat();
        document.getElementById('longitude').value = pos.lng();

        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ location: pos }, (results, status) => {
            if (status === "OK" && results[0]) {
                document.getElementById('address').value = results[0].formatted_address;
            }
        });
    });
}

window.onload = initMap;

document.getElementById("registerForm").addEventListener("submit", function (e) {
    const address = document.getElementById("address").value.trim();
    const lat = document.getElementById("latitude").value.trim();
    const lng = document.getElementById("longitude").value.trim();

    if (!address || !lat || !lng) {
        e.preventDefault();
        document.getElementById('locationError').textContent = "📍 Please select your address from the map or search bar.";
    } else {
        document.getElementById('locationError').textContent = "";
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');

    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });
});
</script>

<?php include 'footer.php'; ?>
