<?php include 'header.php'; ?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="text-center mb-4">Refund Policy</h1>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Our Commitment</h2>
                    <p>At TutorAtHome, we strive to provide the best possible tutoring experience. If you're not satisfied with our services, we offer a fair and transparent refund policy.</p>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Refund Eligibility</h2>
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <h5 class="h6"><i class="fas fa-check-circle text-success me-2"></i>Session Cancellation</h5>
                            <p>If you cancel a session at least 24 hours before the scheduled time, you will receive a full refund.</p>
                        </li>
                        <li class="mb-3">
                            <h5 class="h6"><i class="fas fa-check-circle text-success me-2"></i>Unsatisfactory Service</h5>
                            <p>If you're not satisfied with a tutoring session, you may request a refund within 48 hours of the session.</p>
                        </li>
                        <li class="mb-3">
                            <h5 class="h6"><i class="fas fa-check-circle text-success me-2"></i>Technical Issues</h5>
                            <p>In case of technical issues preventing the session from taking place, you will receive a full refund.</p>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Non-Refundable Items</h2>
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <h5 class="h6"><i class="fas fa-times-circle text-danger me-2"></i>Late Cancellations</h5>
                            <p>Sessions cancelled less than 24 hours before the scheduled time are not eligible for refund.</p>
                        </li>
                        <li class="mb-3">
                            <h5 class="h6"><i class="fas fa-times-circle text-danger me-2"></i>No-Shows</h5>
                            <p>If you don't show up for a scheduled session without prior notice, the session fee will not be refunded.</p>
                        </li>
                        <li class="mb-3">
                            <h5 class="h6"><i class="fas fa-times-circle text-danger me-2"></i>Completed Sessions</h5>
                            <p>Sessions that have been completed and where no issues were reported within 48 hours are not eligible for refund.</p>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">How to Request a Refund</h2>
                    <ol class="mb-0">
                        <li class="mb-2">Contact our support team within 48 hours of the session</li>
                        <li class="mb-2">Provide your booking reference number</li>
                        <li class="mb-2">Explain the reason for your refund request</li>
                        <li class="mb-2">Our team will review your request within 2 business days</li>
                        <li>If approved, the refund will be processed to your original payment method within 5-7 business days</li>
                    </ol>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Contact Us</h2>
                    <p>If you have any questions about our refund policy, please contact our support team:</p>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-envelope me-2"></i> support@tutorathome.com</li>
                        <li class="mb-2"><i class="fas fa-phone me-2"></i> +1 234 567 890</li>
                        <li><i class="fas fa-clock me-2"></i> Monday - Friday, 9:00 AM - 6:00 PM</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 