<?php
include('db.php');
include('header.php');

// Get filter parameters
$rating = isset($_GET['rating']) ? (int)$_GET['rating'] : null;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 9;

// Build query
$where_conditions = ["t.status = 'approved'"];
$params = [];
$types = "";

if ($rating) {
    $where_conditions[] = "t.rating = ?";
    $params[] = $rating;
    $types .= "i";
}

$where_clause = implode(" AND ", $where_conditions);

// Determine sort order
$order_by = match($sort) {
    'oldest' => 't.created_at ASC',
    'highest_rating' => 't.rating DESC, t.created_at DESC',
    'lowest_rating' => 't.rating ASC, t.created_at DESC',
    default => 't.created_at DESC'
};

// Get total count for pagination
$count_sql = "SELECT COUNT(*) as count FROM testimonials t WHERE $where_clause";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$total_testimonials = $count_stmt->get_result()->fetch_assoc()['count'];
$total_pages = ceil($total_testimonials / $per_page);

// Get testimonials
$offset = ($page - 1) * $per_page;
$sql = "SELECT t.*, u.name as student_name 
        FROM testimonials t 
        JOIN users u ON t.student_id = u.id 
        WHERE $where_clause 
        ORDER BY $order_by 
        LIMIT ?, ?";
$params[] = $offset;
$params[] = $per_page;
$types .= "ii";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$testimonials = $stmt->get_result();
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-5">
        <h1 class="mb-0">Student Testimonials</h1>
        <a href="add_testimonial.php" class="btn btn-primary">
            <i class="fas fa-pen me-2"></i>Share Your Experience
        </a>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Filter by Rating</label>
                    <select name="rating" class="form-select">
                        <option value="">All Ratings</option>
                        <?php for ($i = 5; $i >= 1; $i--): ?>
                            <option value="<?= $i ?>" <?= $rating == $i ? 'selected' : '' ?>>
                                <?= $i ?> Stars
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Sort By</label>
                    <select name="sort" class="form-select">
                        <option value="newest" <?= $sort == 'newest' ? 'selected' : '' ?>>Newest First</option>
                        <option value="oldest" <?= $sort == 'oldest' ? 'selected' : '' ?>>Oldest First</option>
                        <option value="highest_rating" <?= $sort == 'highest_rating' ? 'selected' : '' ?>>Highest Rating</option>
                        <option value="lowest_rating" <?= $sort == 'lowest_rating' ? 'selected' : '' ?>>Lowest Rating</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i>Apply Filters
                    </button>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <a href="testimonials.php" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-undo me-2"></i>Reset Filters
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Testimonials Grid -->
    <div class="row g-4">
        <?php if ($testimonials->num_rows > 0): ?>
            <?php while ($testimonial = $testimonials->fetch_assoc()): ?>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm p-4 hover-shadow">
                        <div class="d-flex align-items-center mb-3">
                            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <h5 class="mb-0"><?= htmlspecialchars($testimonial['student_name']) ?></h5>
                                <div class="text-warning">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star<?= $i <= $testimonial['rating'] ? '' : '-o' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                        <p class="text-muted"><?= htmlspecialchars($testimonial['content']) ?></p>
                        <small class="text-muted">
                            <i class="far fa-clock me-1"></i>
                            <?= date('F j, Y', strtotime($testimonial['created_at'])) ?>
                        </small>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info text-center">
                    <i class="fas fa-info-circle me-2"></i>No testimonials found matching your criteria.
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Testimonials pagination" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page - 1 ?>&rating=<?= $rating ?>&sort=<?= $sort ?>">Previous</a>
                    </li>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>&rating=<?= $rating ?>&sort=<?= $sort ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $page + 1 ?>&rating=<?= $rating ?>&sort=<?= $sort ?>">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<style>
.hover-shadow {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-shadow:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
}
</style>

<?php include('footer.php'); ?> 