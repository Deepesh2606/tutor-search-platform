<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please login to vote");
    exit();
}

if (!isset($_GET['answer_id']) || !is_numeric($_GET['answer_id']) || !isset($_GET['action'])) {
    $_SESSION['vote_message'] = ["type" => "error", "text" => "Invalid request."];
    header("Location: qna.php");
    exit();
}

$answer_id = $_GET['answer_id'];
$action = $_GET['action'];
$user_id = $_SESSION['user_id'];

// Get question ID for redirect
$stmt = $conn->prepare("SELECT question_id FROM answers WHERE id = ?");
$stmt->bind_param('i', $answer_id);
$stmt->execute();
$result = $stmt->get_result();
$question_id = $result->fetch_assoc()['question_id'];

// Validate action
if ($action !== 'like' && $action !== 'dislike') {
    $_SESSION['vote_message'] = ["type" => "error", "text" => "Invalid action."];
    header("Location: view-answers.php?question_id=" . $question_id);
    exit();
}

// Check for existing vote
$stmt = $conn->prepare("SELECT vote_type FROM answer_votes WHERE user_id = ? AND answer_id = ?");
$stmt->bind_param('ii', $user_id, $answer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $existing_vote = $result->fetch_assoc()['vote_type'];
    $_SESSION['vote_message'] = [
        "type" => "info",
        "text" => "You have already " . $existing_vote . 'd this answer.'
    ];
    header("Location: view-answers.php?question_id=" . $question_id . "#answer_" . $answer_id);
    exit();
}

// Insert new vote
$stmt = $conn->prepare("INSERT INTO answer_votes (user_id, answer_id, vote_type) VALUES (?, ?, ?)");
$stmt->bind_param('iis', $user_id, $answer_id, $action);

if ($stmt->execute()) {
    // Update vote count
    $update_field = $action === 'like' ? 'likes = likes + 1' : 'dislikes = dislikes + 1';
    $stmt = $conn->prepare("UPDATE answers SET $update_field WHERE id = ?");
    $stmt->bind_param('i', $answer_id);
    
    if ($stmt->execute()) {
        $_SESSION['vote_message'] = ["type" => "success", "text" => "Your vote has been recorded."];
    } else {
        $_SESSION['vote_message'] = ["type" => "error", "text" => "Error updating vote count."];
    }
} else {
    $_SESSION['vote_message'] = ["type" => "error", "text" => "Error recording your vote."];
}

header("Location: view-answers.php?question_id=" . $question_id . "#answer_" . $answer_id);
exit();
?>
