<?php
session_start();
include 'db.php';

$user_id = $_SESSION['user_id'];
$subject = $_POST['subject'];
$question = $_POST['question'];
$imagePath = null;

// Handle image upload
if ($_FILES['image']['name']) {
    $targetDir = "img/questions/";
    $imageName = time() . "_" . basename($_FILES["image"]["name"]);
    $targetFile = $targetDir . $imageName;

    move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
    $imagePath = $targetFile;
}

$query = "INSERT INTO questions (user_id, subject, question, image) VALUES ('$user_id', '$subject', '$question', '$imagePath')";
mysqli_query($conn, $query);

header("Location: qna.php");
