<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tutor') {
    header("Location: login.php");
    exit();
}

$request_id = $_GET['request_id'];
$action = $_GET['action'];
$tutor_id = $_SESSION['user_id'];

// Update the request based on action
if ($action === 'accept') {
    $sql = "UPDATE requests SET status = 'accepted' WHERE id = $request_id";
    $conn->query($sql);

    // Reject any other pending requests for the same student and subject
    $sql_reject = "UPDATE requests SET status = 'rejected' WHERE student_id = (SELECT student_id FROM requests WHERE id = $request_id) AND status = 'pending'";
    $conn->query($sql_reject);

    echo "✅ You have accepted the request!";
} elseif ($action === 'reject') {
    $sql = "UPDATE requests SET status = 'rejected' WHERE id = $request_id";
    $conn->query($sql);

    echo "❌ You have rejected the request.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Request Accepted/Rejected</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
  <?php include('tutor_header.php'); ?>
  <div class="container mt-4">
    <h2>Status Updated!</h2>
    <a href="tutor-dashboard.php" class="btn btn-primary">Go back to Dashboard</a>
  </div>
</body>
</html>
<?php include'footer.php';?>