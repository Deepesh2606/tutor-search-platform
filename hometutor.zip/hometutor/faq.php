<?php include 'header.php'; ?>

<div class="container py-5">
    <h1 class="text-center mb-5">Frequently Asked Questions</h1>

    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- General Questions -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-4">General Questions</h2>
                    
                    <div class="accordion" id="generalAccordion">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#general1">
                                    What is TutorAtHome?
                                </button>
                            </h3>
                            <div id="general1" class="accordion-collapse collapse show" data-bs-parent="#generalAccordion">
                                <div class="accordion-body">
                                    TutorAtHome is an online platform that connects students with qualified tutors for personalized learning experiences. We offer one-on-one tutoring, group classes, and online sessions across various subjects.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#general2">
                                    How do I find a tutor?
                                </button>
                            </h3>
                            <div id="general2" class="accordion-collapse collapse" data-bs-parent="#generalAccordion">
                                <div class="accordion-body">
                                    You can find a tutor by visiting our "Find Tutors" page and using the search filters to find tutors based on subject, level, and location. Each tutor profile includes their qualifications, experience, and reviews from other students.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Booking Questions -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-4">Booking & Sessions</h2>
                    
                    <div class="accordion" id="bookingAccordion">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#booking1">
                                    How do I book a session?
                                </button>
                            </h3>
                            <div id="booking1" class="accordion-collapse collapse show" data-bs-parent="#bookingAccordion">
                                <div class="accordion-body">
                                    To book a session, first create an account, then browse available tutors. Once you find a suitable tutor, select your preferred time slot and complete the payment process. You'll receive a confirmation email with session details.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#booking2">
                                    Can I reschedule or cancel a session?
                                </button>
                            </h3>
                            <div id="booking2" class="accordion-collapse collapse" data-bs-parent="#bookingAccordion">
                                <div class="accordion-body">
                                    Yes, you can reschedule or cancel a session up to 24 hours before the scheduled time through your account dashboard. Please refer to our refund policy for more details.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Questions -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-4">Payments & Pricing</h2>
                    
                    <div class="accordion" id="paymentAccordion">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#payment1">
                                    What payment methods do you accept?
                                </button>
                            </h3>
                            <div id="payment1" class="accordion-collapse collapse show" data-bs-parent="#paymentAccordion">
                                <div class="accordion-body">
                                    We accept all major credit cards (Visa, MasterCard, American Express), PayPal, and bank transfers. All payments are processed securely through our payment gateway.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#payment2">
                                    Are there any hidden fees?
                                </button>
                            </h3>
                            <div id="payment2" class="accordion-collapse collapse" data-bs-parent="#paymentAccordion">
                                <div class="accordion-body">
                                    No, there are no hidden fees. The price you see is the price you pay. All our pricing is transparent and includes any platform fees.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Technical Questions -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-4">Technical Support</h2>
                    
                    <div class="accordion" id="techAccordion">
                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#tech1">
                                    What do I need for online sessions?
                                </button>
                            </h3>
                            <div id="tech1" class="accordion-collapse collapse show" data-bs-parent="#techAccordion">
                                <div class="accordion-body">
                                    For online sessions, you'll need a stable internet connection, a computer or tablet with a webcam and microphone, and a modern web browser. We recommend using Google Chrome or Firefox for the best experience.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tech2">
                                    What if I have technical issues during a session?
                                </button>
                            </h3>
                            <div id="tech2" class="accordion-collapse collapse" data-bs-parent="#techAccordion">
                                <div class="accordion-body">
                                    If you experience technical issues during a session, please try refreshing your browser first. If the problem persists, contact our support team immediately. We'll help resolve the issue or reschedule the session if needed.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Contact Section -->
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <h2 class="h4 mb-3">Still Have Questions?</h2>
                    <p class="mb-4">Can't find the answer you're looking for? Our support team is here to help!</p>
                    <a href="contact.php" class="btn btn-primary">Contact Support</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 