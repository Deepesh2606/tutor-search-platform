<?php
session_start();
include('db.php');

// Check if the user is logged in and is a tutor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tutor') {
    header('Location: tutor_login.php');
    exit();
}

$tutor_id = $_SESSION['user_id'];
$tutor = [];

// Fetch tutor details
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $tutor = $result->fetch_assoc();
} else {
    die('Tutor not found!');
}

// Fetch tutor's requests
$sql_requests = "SELECT * FROM tutor_requests WHERE tutor_id = ? ORDER BY request_date DESC";
$stmt_requests = $conn->prepare($sql_requests);
$stmt_requests->bind_param("i", $tutor_id);
$stmt_requests->execute();
$result_requests = $stmt_requests->get_result();

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['accept_request_id'])) {
        $request_id = $_POST['accept_request_id'];
        
        // Update status to 'accepted'
        $sql_update = "UPDATE tutor_requests SET request_status = 'accepted' WHERE request_id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("i", $request_id);
        $stmt_update->execute();
        
        // Get student details to send WhatsApp message
        $sql_student = "SELECT name, phone, email FROM users WHERE id = (SELECT student_id FROM tutor_requests WHERE request_id = ?)";
        $stmt_student = $conn->prepare($sql_student);
        $stmt_student->bind_param("i", $request_id);
        $stmt_student->execute();
        $result_student = $stmt_student->get_result();

        if ($result_student->num_rows > 0) {
            $student = $result_student->fetch_assoc();
            $student_phone = $student['phone'];

            // Send a WhatsApp message
           $whatsapp_message = urlencode(
    "Dear Student,\n\n" .
    "I am pleased to inform you that I have accepted your tutoring request. " .
    "I look forward to assisting you in your studies.\n\n" .
    "Tutor Details:\n" .
    "Name: " . $tutor['name'] . "\n" .
    "Email: " . $tutor['email'] . "\n\n" .
    "Please let me know your preferred time for the first session.\n\n" .
    "Best regards,\n" .
    $tutor['name']
);

            $whatsapp_url = "https://wa.me/$student_phone?text=$whatsapp_message";
            
            // Redirect to WhatsApp chat
            header("Location: $whatsapp_url");
            exit();
        }
    } elseif (isset($_POST['complete_request_id'])) {
        $request_id = $_POST['complete_request_id'];
        
        // Update status to 'completed'
        $sql_update = "UPDATE tutor_requests SET request_status = 'completed' WHERE request_id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("i", $request_id);
        $stmt_update->execute();
        
        // Refresh the page to show updated status
        header("Location: tutor_index.php");
        exit();
    } elseif (isset($_POST['reject_request_id'])) {
        $request_id = $_POST['reject_request_id'];
        
        // Update status to 'rejected'
        $sql_update = "UPDATE tutor_requests SET request_status = 'rejected' WHERE request_id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("i", $request_id);
        $stmt_update->execute();
        
        // Refresh the page to show updated status
        header("Location: tutor_index.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Tutor Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body style="background: #f0f2f5;">

    <?php include('tutor_header.php'); ?>

    <div class="container py-5">
        <div class="welcome-card mb-5">
            <div class="d-flex align-items-center">
                <div class="welcome-icon me-3">
                    <i class="fas fa-chalkboard-teacher fa-3x" style="color: #0F1C4D;"></i>
                </div>
                <div>
                    <h1 class="welcome-title">Welcome, <?= htmlspecialchars($tutor['name']) ?></h1>
                    <p class="welcome-subtitle">Manage your tutoring requests and students</p>
                </div>
            </div>
        </div>

        <div class="requests-section">
            <h2 class="section-title mb-4">
                <i class="fas fa-tasks me-2"></i>Your Student Requests
            </h2>

            <?php if ($result_requests->num_rows > 0): ?>
            <div class="row">
                <?php while ($row = $result_requests->fetch_assoc()): ?>
                <?php
                    $student_id = $row['student_id'];
                    $sql_student_details = "SELECT name, phone, email FROM users WHERE id = ?";
                    $stmt_student_details = $conn->prepare($sql_student_details);
                    $stmt_student_details->bind_param("i", $student_id);
                    $stmt_student_details->execute();
                    $result_student_details = $stmt_student_details->get_result();

                    if ($result_student_details->num_rows > 0) {
                        $student_details = $result_student_details->fetch_assoc();
                        $student_name = $student_details['name'];
                        $student_phone = $student_details['phone'];
                        $student_email = $student_details['email'];
                    }
                    ?>

                <div class="col-md-6 mb-4">
                    <div class="request-card">
                        <div class="request-header">
                            <h3 class="student-name">
                                <i class="fas fa-user-graduate me-2"></i>
                                <?= htmlspecialchars($student_name) ?>
                            </h3>
                            <span class="status-badge status-<?= $row['request_status'] ?>">
                                <?= ucfirst(htmlspecialchars($row['request_status'])) ?>
                            </span>
                        </div>

                        <div class="request-details">
                            <div class="detail-item">
                                <i class="fas fa-phone me-2"></i>
                                <span><?= htmlspecialchars($student_phone) ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-envelope me-2"></i>
                                <span><?= htmlspecialchars($student_email) ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-calendar me-2"></i>
                                <span>Requested on: <?= htmlspecialchars($row['request_date']) ?></span>
                            </div>
                        </div>

                        <div class="request-actions">
                            <?php if ($row['request_status'] === 'pending'): ?>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="accept_request_id" value="<?= $row['request_id'] ?>">
                                <button type="submit" class="btn btn-primary action-btn">
                                    <i class="fas fa-check me-2"></i>Accept Request
                                </button>
                            </form>
                            <form method="POST" class="d-inline ms-2">
                                <input type="hidden" name="reject_request_id" value="<?= $row['request_id'] ?>">
                                <button type="submit" class="btn btn-danger action-btn">
                                    <i class="fas fa-times me-2"></i>Reject Request
                                </button>
                            </form>
                            <?php endif; ?>

                            <?php if ($row['request_status'] === 'accepted'): ?>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="complete_request_id" value="<?= $row['request_id'] ?>">
                                <button type="submit" class="btn btn-success action-btn">
                                    <i class="fas fa-flag-checkered me-2"></i>Mark as Completed
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php else: ?>
            <div class="no-requests">
                <i class="fas fa-inbox fa-3x mb-3"></i>
                <h3>No Student Requests</h3>
                <p class="text-muted">You have no student requests at the moment.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <style>
    .welcome-card {
        background: white;
        padding: 2rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }

    .welcome-title {
        color: #0F1C4D;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }

    .welcome-subtitle {
        color: #6c757d;
        margin-bottom: 0;
    }

    .section-title {
        color: #0F1C4D;
        font-weight: 600;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid #e9ecef;
    }

    .request-card {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease;
        height: 100%;
    }

    .request-card:hover {
        transform: translateY(-5px);
    }

    .request-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
    }

    .student-name {
        color: #0F1C4D;
        font-size: 1.25rem;
        font-weight: 600;
        margin: 0;
    }

    .status-badge {
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-weight: 500;
        font-size: 0.875rem;
    }

    .status-pending {
        background: #fff3cd;
        color: #856404;
    }

    .status-accepted {
        background: #cce5ff;
        color: #004085;
    }

    .status-completed {
        background: #d4edda;
        color: #155724;
    }

    .status-rejected {
        background: #f8d7da;
        color: #721c24;
    }

    .request-details {
        margin-bottom: 1.5rem;
    }

    .detail-item {
        display: flex;
        align-items: center;
        margin-bottom: 0.75rem;
        color: #495057;
    }

    .detail-item i {
        color: #0F1C4D;
        width: 20px;
    }

    .request-actions {
        margin-top: auto;
    }

    .action-btn {
        padding: 0.5rem 1.5rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .no-requests {
        text-align: center;
        padding: 3rem;
        background: white;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }

    .no-requests i {
        color: #0F1C4D;
        opacity: 0.5;
    }

    @media (max-width: 768px) {
        .welcome-card {
            padding: 1.5rem;
        }

        .request-card {
            padding: 1.25rem;
        }

        .status-badge {
            padding: 0.375rem 0.75rem;
            font-size: 0.75rem;
        }
    }
    </style>

    <?php include('footer.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>