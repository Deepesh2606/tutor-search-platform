<?php
include('db.php');

// Fetch tutor data
if (!isset($_SESSION['user_id'])) {
    header("Location: tutor_login.php");
    exit();
}

$tutor_id = $_SESSION['user_id'];

$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$result = $stmt->get_result();
$tutor = $result->fetch_assoc();

// Check if profile is complete
$fields = ['name', 'email', 'phone', 'address', 'profile_picture', 'latitude', 'longitude'];
$profile_complete = true;

foreach ($fields as $field) {
    if (empty($tutor[$field])) {
        $profile_complete = false;
        break;
    }
}
?>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background: linear-gradient(90deg, #0F1C4D, #1E3A8A); box-shadow: 0 4px 15px rgba(0,0,0,0.2); backdrop-filter: blur(10px);">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="tutor_index.php">
            <i class="fas fa-chalkboard-teacher me-2"></i>
            <span class="navbar-text" style="font-size: 24px; font-weight: 700; color: white; letter-spacing: 1px;">
                Tutor Dashboard
            </span>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
            <ul class="navbar-nav align-items-lg-center">
                <li class="nav-item">
                    <a class="nav-link text-light px-3 py-2 rounded-3" href="tutor_index.php">
                        <i class="fas fa-home me-2"></i>Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light px-3 py-2 rounded-3" href="tutor_qna.php">
                        <i class="fas fa-tasks me-2"></i>QnA
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light px-3 py-2 rounded-3" href="tutor_profile.php">
                        <div class="d-flex align-items-center">
                            <img src="img/profilepic/<?= htmlspecialchars($tutor['profile_picture'] ?? 'default-profile.png') ?>" 
                                alt="Profile" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">
                            <span>Profile</span>
                        </div>
                    </a>
                </li>
            </ul>

            <div class="d-flex align-items-center ms-lg-4 mt-3 mt-lg-0">
                <div class="text-light me-3 d-flex align-items-center">
                    <i class="fas fa-user-circle me-2"></i>
                    <span>Hello, <?= htmlspecialchars($tutor['name']); ?></span>
                </div>
                <a href="tutor_logout.php" class="btn btn-outline-light btn-sm px-3 py-2 rounded-3">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </div>
</nav>

<!-- Styles -->
<style>
.nav-link {
    transition: all 0.3s ease;
    margin: 0 2px;
    position: relative;
    font-weight: 500;
}

.nav-link:hover {
    background-color: rgba(255, 255, 255, 0.15);
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.nav-link::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 2px;
    background: rgba(255, 255, 255, 0.3);
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

.nav-link:hover::after {
    transform: scaleX(1);
}

.btn-outline-light {
    transition: all 0.3s ease;
    border-width: 2px;
    font-weight: 500;
}

.btn-outline-light:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(255, 255, 255, 0.2);
    background-color: rgba(255, 255, 255, 0.1);
}

.navbar {
    padding: 0.8rem 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.navbar-brand {
    transition: transform 0.3s ease;
}

.navbar-brand:hover {
    transform: translateY(-2px);
}

@media (max-width: 991.98px) {
    .navbar-nav {
        padding: 1rem 0;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 10px;
    }
    
    .nav-link {
        padding: 0.8rem 1.2rem !important;
        margin: 0.2rem 0;
    }
}
</style>

<!-- Bootstrap JS -->
 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
