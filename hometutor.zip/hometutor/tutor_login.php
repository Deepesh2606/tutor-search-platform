<?php
session_start(); // Start the session to manage login state

include('db.php'); // Include database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize form data
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // Check if the user exists in the database (prepared statement)
    $sql = "SELECT * FROM users WHERE email = ? AND role = 'tutor'";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Failed to prepare statement: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Login successful, start session and redirect to Tutor Panel
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            // Check if the session is set properly
            if (isset($_SESSION['user_id'])) {
                header("Location: tutor_index.php");  // Redirect to Tutor Panel
                exit(); // Prevent further script execution after redirect
            } else {
                echo "Session not set correctly!";
            }
        } else {
            $error = "Invalid password! Please try again.";
        }
    } else {
        $error = "No tutor found with that email! Please make sure you are registered as a tutor.";
    }
}

include('header.php');
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="text-center mb-4">
            <i class="fas fa-chalkboard-teacher fa-3x mb-3" style="color: #1E3A8A;"></i>
            <h2 class="auth-title">Tutor Login</h2>
            <p class="text-muted">Welcome back! Please login to your tutor account</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger text-center">
                <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-envelope me-2"></i>Email Address
                </label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-lock me-2"></i>Password
                </label>
                <div class="input-group">
                    <input type="password" name="password" class="form-control" id="password" required>
                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary auth-btn">
                <i class="fas fa-sign-in-alt me-2"></i>Login
            </button>
        </form>

        <div class="auth-footer text-center mt-4">
            <p class="mb-0">New tutor? 
                <a href="tutor_register.php" class="auth-link">
                    <i class="fas fa-user-plus me-1"></i>Register here
                </a>
            </p>
        </div>
    </div>
</div>

<style>
.auth-container {
    min-height: calc(100vh - 76px);
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 2rem;
}

.auth-card {
    background: white;
    padding: 2.5rem;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 450px;
}

.auth-title {
    color: #1E3A8A;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    color: #495057;
    font-weight: 500;
    margin-bottom: 0.5rem;
    display: block;
}

.form-control {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: #1E3A8A;
    box-shadow: 0 0 0 0.2rem rgba(30, 58, 138, 0.15);
}

.auth-btn {
    background: linear-gradient(135deg, #1E3A8A, #0F1C4D);
    border: none;
    border-radius: 8px;
    padding: 0.75rem;
    font-weight: 600;
    width: 100%;
    transition: all 0.3s ease;
}

.auth-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 58, 138, 0.3);
}

.auth-link {
    color: #1E3A8A;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.auth-link:hover {
    color: #0F1C4D;
    text-decoration: underline;
}

.alert {
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 1.5rem;
}

@media (max-width: 576px) {
    .auth-card {
        padding: 2rem 1.5rem;
    }
    
    .auth-container {
        padding: 1rem;
    }
}

.input-group {
    position: relative;
}

.input-group .btn {
    border-color: #e9ecef;
    background: transparent;
    transition: all 0.3s ease;
}

.input-group .btn:hover {
    background: rgba(30, 58, 138, 0.1);
    border-color: #1E3A8A;
}

.input-group .btn i {
    color: #1E3A8A;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');

    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });
});
</script>

<?php include('footer.php'); ?>
