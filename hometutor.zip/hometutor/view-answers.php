<?php
session_start();
include 'db.php';
include 'header.php';

if (!isset($_GET['question_id']) || !is_numeric($_GET['question_id'])) {
    die("Invalid question ID.");
}

$question_id = $_GET['question_id'];
$user_id = $_SESSION['user_id'] ?? null;


// Fetch the question details
$query = "SELECT * FROM questions WHERE id = '$question_id'";
$result = mysqli_query($conn, $query);
$question = mysqli_fetch_assoc($result);
?>

<style>
    .answer-container {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        margin-left: 20px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .answer-container:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }

    .vote-buttons {
        margin-top: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .vote-buttons a {
        text-decoration: none;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 0.9em;
        transition: all 0.2s ease;
    }

    .like-button {
        background-color: #4CAF50;
        color: white;
    }

    .like-button:hover {
        background-color: #45a049;
    }

    .dislike-button {
        background-color: #f44336;
        color: white;
    }

    .dislike-button:hover {
        background-color: #da190b;
    }

    .vote-count {
        font-weight: 600;
        margin-right: 15px;
        color: #666;
    }

    .answer-image {
        max-width: 300px; /* Reduced from 100% */
        height: auto;
        margin-top: 15px;
        border-radius: 6px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        display: block; /* Added for better alignment */
        margin-left: auto;
        margin-right: auto;
    }

    .card {
        border: none;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }

    .card-body {
        padding: 25px;
    }

    .card-body h2 {
        color: #333;
        margin-bottom: 20px;
        font-weight: 600;
    }

    .card-body p {
        margin-bottom: 10px;
        color: #555;
    }

    .answer-content {
        line-height: 1.6;
        color: #333;
    }

    .answer-content strong {
        color: #2c3e50;
        font-size: 1.1em;
    }

    .text-muted {
        margin-top: 10px;
        font-size: 0.9em;
    }

    .btn-primary {
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 500;
        transition: all 0.2s ease;
    }

    .btn-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    h3 {
        color: #2c3e50;
        margin: 30px 0 20px;
        font-weight: 600;
    }
</style>

<div class="container mt-4">
    <div class="card mb-4">
        <div class="card-body">
            <h2>Question Details</h2>
            <p><strong>Question:</strong> <?= htmlspecialchars($question['question']) ?></p>
            <p><strong>Subject:</strong> <?= htmlspecialchars($question['subject']) ?></p>
        </div>
    </div>

    <h3>Answers</h3>
    <?php
    // Fetch all answers for the question
    $answers = mysqli_query($conn, "SELECT a.*, u.name FROM answers a JOIN users u ON a.user_id = u.id WHERE question_id = '$question_id' ORDER BY a.created_at ASC");

    while ($a = mysqli_fetch_assoc($answers)) {
        // Check if the user has already voted on this answer
        $answer_id = $a['id'];
        $vote_check = mysqli_query($conn, "SELECT * FROM answer_votes WHERE answer_id = '$answer_id' AND user_id = '$user_id'");

        $user_vote = mysqli_fetch_assoc($vote_check);
        $user_liked = false;
        $user_disliked = false;

        if ($user_vote) {
            if ($user_vote['vote_type'] == 'like') {
                $user_liked = true;
            } elseif ($user_vote['vote_type'] == 'dislike') {
                $user_disliked = true;
            }
        }

        // Get likes and dislikes count
        $likes_query = mysqli_query($conn, "SELECT COUNT(*) AS likes FROM answer_votes WHERE answer_id = '$answer_id' AND vote_type = 'like'");
        $dislikes_query = mysqli_query($conn, "SELECT COUNT(*) AS dislikes FROM answer_votes WHERE answer_id = '$answer_id' AND vote_type = 'dislike'");
        $likes = mysqli_fetch_assoc($likes_query)['likes'];
        $dislikes = mysqli_fetch_assoc($dislikes_query)['dislikes'];
    ?>
        <div class="answer-container">
            <div class="answer-content">
                <strong>Answer by <?= htmlspecialchars($a['name']) ?>:</strong><br>
                <?= nl2br(htmlspecialchars($a['answer'])) ?>
                <?php if ($a['image']): ?>
                    <img src="<?= htmlspecialchars($a['image']) ?>" class="answer-image" alt="Answer image">
                <?php endif; ?>
            </div>
            
            <div class="text-muted small">
                <em>Posted on: <?= $a['created_at'] ?></em>
            </div>

            <div class="vote-buttons">
                <span class="vote-count">👍 <?= $likes ?></span>
                <span class="vote-count">👎 <?= $dislikes ?></span>
                
                <?php if (!$user_liked && !$user_disliked): ?>
                    <a href="vote.php?action=like&answer_id=<?= $a['id'] ?>" class="like-button">Like</a>
                    <a href="vote.php?action=dislike&answer_id=<?= $a['id'] ?>" class="dislike-button">Dislike</a>
                <?php elseif ($user_liked): ?>
                    <span style="color: #4CAF50;">You liked this answer</span>
                <?php elseif ($user_disliked): ?>
                    <span style="color: #f44336;">You disliked this answer</span>
                <?php endif; ?>
            </div>
        </div>
    <?php } ?>

    <a href="qna.php" class="btn btn-primary mt-3">Back to Q&A Section</a>
</div>
