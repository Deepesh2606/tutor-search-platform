<?php
echo password_hash('Admin@12_', PASSWORD_DEFAULT);
?>
