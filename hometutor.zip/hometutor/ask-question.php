<?php
session_start(); // Start session if not already
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please login or signup to ask a question");
    exit;
}
?>

<?php include 'db.php'; ?>
<?php include 'header.php'; ?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Ask a Question</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="submit-question.php" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="subject" class="form-label">Select Subject:</label>
                            <select name="subject" id="subject" class="form-select" required>
                                <option value="">--Select Subject--</option>
                                <?php
                                // Fetching subjects from the database
                                $subject_query = $conn->query("SELECT * FROM subjects ORDER BY name ASC");
                                while ($row = $subject_query->fetch_assoc()) {
                                    echo "<option value='{$row['name']}'>{$row['name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="question" class="form-label">Your Question:</label>
                            <textarea name="question" id="question" class="form-control" rows="5" placeholder="Type your question here..." required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="image" class="form-label">Attach Image (Optional):</label>
                            <input type="file" name="image" id="image" class="form-control" accept="image/*">
                            <div class="form-text">Supported formats: JPG, PNG, GIF</div>
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-paper-plane me-2"></i>Post Question
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
