<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "Please login to view your bookings";
    header("Location: login.php");
    exit();
}

include('db.php');

$student_id = $_SESSION['user_id'];
$student = [];

// Fetch student details
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    die('Student not found!');
}

// Fetch student's bookings (example: tutor requests table)
$sql_bookings = "SELECT * FROM tutor_requests WHERE student_id = ? ORDER BY request_date DESC";
$stmt_bookings = $conn->prepare($sql_bookings);
$stmt_bookings->bind_param("i", $student_id);
$stmt_bookings->execute();
$result_bookings = $stmt_bookings->get_result();

// Handle cancellation of bookings
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_request_id'])) {
    $request_id = $_POST['cancel_request_id'];
    
    // Update status to 'cancelled'
    $sql_update = "UPDATE tutor_requests SET request_status = 'cancelled' WHERE request_id = ? AND student_id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ii", $request_id, $student_id);
    $stmt_update->execute();
    
    // Refresh the page to show updated status
    header("Location: mybookings.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Bookings</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0f7f0;
        }
        .container {
            max-width: 1200px;
        }
        .welcome-header {
            color: #2c5530;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e0e8e0;
        }
        .list-group-item {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.2s;
            margin-bottom: 1.5rem;
            padding: 1.5rem;
            border: none;
        }
        .list-group-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .status-badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
            margin-bottom: 1rem;
        }
        .status-accepted {
            background-color: #d4edda;
            color: #155724;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-rejected {
            background-color: #f8d7da;
            color: #721c24;
        }
        .status-completed {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        .status-cancelled {
    background-color: #e2e3e5;
    color: #41464b;
}

        .contact-info {
            background-color: #f0f7f0;
            padding: 1rem;
            border-radius: 5px;
            margin: 1rem 0;
            border: 1px solid #e0e8e0;
        }
        .no-bookings {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .no-bookings i {
            font-size: 3rem;
            color: #6c757d;
            margin-bottom: 1rem;
        }
        .tutor-name {
            font-size: 1.25rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: #2c5530;
        }
        .request-date {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .text-success {
            color: #2c5530 !important;
        }
        .text-warning {
            color: #856404 !important;
        }
        .text-danger {
            color: #721c24 !important;
        }
    </style>
</head>
<body>

<?php include('header.php'); ?>

<div class="container mt-4">
    <h2 class="welcome-header">Welcome, <?= htmlspecialchars($student['name']) ?> 📚</h2>

    <!-- Student Bookings -->
    <h4 class="mb-4">Your Bookings:</h4>

    <?php if ($result_bookings->num_rows > 0): ?>
        <div class="list-group">
            <?php while ($row = $result_bookings->fetch_assoc()): ?>
                <div class="list-group-item">
                    
                    <!-- Get tutor details -->
                    <?php
                    $tutor_id = $row['tutor_id'];
                    $sql_tutor_details = "SELECT name, phone, email FROM users WHERE id = ?";
                    $stmt_tutor_details = $conn->prepare($sql_tutor_details);
                    $stmt_tutor_details->bind_param("i", $tutor_id);
                    $stmt_tutor_details->execute();
                    $result_tutor_details = $stmt_tutor_details->get_result();

                    if ($result_tutor_details->num_rows > 0) {
                        $tutor_details = $result_tutor_details->fetch_assoc();
                        $tutor_name = $tutor_details['name'];
                        $tutor_phone = $tutor_details['phone'];
                        $tutor_email = $tutor_details['email'];
                    }
                    ?>

                    <div class="tutor-name"><?= htmlspecialchars($tutor_name) ?></div>
                    <span class="status-badge status-<?= $row['request_status'] ?>">
                        <?= ucfirst($row['request_status']) ?>
                    </span>
                    
                    <?php if ($row['request_status'] === 'accepted'): ?>
                        <div class="contact-info">
                            <p class="mb-2"><strong>Phone:</strong> <?= htmlspecialchars($tutor_phone) ?></p>
                            <p class="mb-0"><strong>Email:</strong> <?= htmlspecialchars($tutor_email) ?></p>
                        </div>
                    <?php endif; ?>

                    <p class="request-date">
                        Requested on: <?= (new DateTime($row['request_date']))->format('l, F j, Y \a\t h:i A') ?>
                    </p>

                    <?php if ($row['request_status'] === 'accepted'): ?>
                        <p class="text-success">Your request has been accepted by the tutor. You can contact them now.</p>
                    <?php elseif ($row['request_status'] === 'pending'): ?>
                        <p class="text-warning">Your request is still pending. Please wait for the tutor to accept.</p>
                    <?php elseif ($row['request_status'] === 'rejected'): ?>
                        <p class="text-danger">Your request has been rejected by the tutor.</p>
                    <?php elseif ($row['request_status'] === 'cancelled'): ?>
                        <p class="text-danger">You have cancelled this request.</p>
                    <?php endif; ?>

                    <?php if ($row['request_status'] === 'pending' || $row['request_status'] === 'accepted'): ?>
                        <form method="POST" class="mt-3">
                            <input type="hidden" name="cancel_request_id" value="<?= $row['request_id'] ?>">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this booking?')">
                                <i class="fas fa-times"></i> Cancel Booking
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="no-bookings">
            <i class="fas fa-calendar-times"></i>
            <h4 class="text-muted">You have no bookings at the moment.</h4>
        </div>
    <?php endif; ?>
</div>

<?php include('footer.php'); ?>

<!-- Bootstrap JS and Font Awesome -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

</body>
</html>
