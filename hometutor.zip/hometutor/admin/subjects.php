<?php
session_start();
include('db.php');
include('header.php');

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    $_SESSION['message'] = "Please sign in to access this page";
    header("Location: login.php");
    exit();
}

$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle subject deletion
    if (isset($_POST['delete_subject'])) {
        $subject_id = $_POST['subject_id'];
        $delete_sql = "DELETE FROM subjects WHERE id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("i", $subject_id);
        
        if ($stmt->execute()) {
            $message = "✅ Subject deleted successfully!";
        } else {
            $message = "❌ Error deleting subject: " . $conn->error;
        }
        $stmt->close();
    } else {
        // Handle subject addition (existing code)
        $subject_name = trim($_POST['subject_name']);

        if (!empty($subject_name)) {
            $sql = "INSERT INTO subjects (name) VALUES (?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $subject_name);

            if ($stmt->execute()) {
                $message = "✅ Subject added successfully!";
            } else {
                $message = "❌ Error adding subject: " . $conn->error;
            }

            $stmt->close();
        } else {
            $message = "❌ Subject name cannot be empty.";
        }
    }
}

// Fetch all subjects
$subjects_query = "SELECT * FROM subjects ORDER BY name ASC";
$subjects_result = $conn->query($subjects_query);
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Add New Subject</h4>
                </div>
                <div class="card-body">
                    <?php if (!empty($message)): ?>
                        <div class="alert <?php echo strpos($message, '✅') !== false ? 'alert-success' : 'alert-danger'; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="subject_name" class="form-label">Subject Name</label>
                            <input type="text" class="form-control" id="subject_name" name="subject_name" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Subject</button>
                    </form>
                </div>
            </div>

            <!-- List of Existing Subjects -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-light">
                    <h4 class="mb-0">Existing Subjects</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Subject Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($subject = $subjects_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $subject['id']; ?></td>
                                        <td><?php echo htmlspecialchars($subject['name']); ?></td>
                                        <td>
                                            <form method="POST" action="" style="display: inline;">
                                                <input type="hidden" name="subject_id" value="<?php echo $subject['id']; ?>">
                                                <button type="submit" name="delete_subject" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this subject?')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include('footer.php'); ?>
