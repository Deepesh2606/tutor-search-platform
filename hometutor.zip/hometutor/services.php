<?php include 'header.php'; ?>

<div class="container py-5">
    <h1 class="text-center mb-5">Our Services</h1>
    
    <div class="row">
        <!-- One-on-One Tutoring -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body text-center">
                    <i class="fas fa-user-graduate fa-3x text-primary mb-3"></i>
                    <h3 class="h4 mb-3">One-on-One Tutoring</h3>
                    <p>Personalized attention and customized learning plans tailored to your specific needs and learning style.</p>
                    <ul class="list-unstyled text-start">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Individual attention</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Flexible scheduling</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Custom learning plans</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Group Classes -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body text-center">
                    <i class="fas fa-users fa-3x text-primary mb-3"></i>
                    <h3 class="h4 mb-3">Group Classes</h3>
                    <p>Interactive learning in small groups with peers, perfect for collaborative learning and social interaction.</p>
                    <ul class="list-unstyled text-start">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Small group sizes</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Collaborative learning</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Cost-effective option</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Online Tutoring -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body text-center">
                    <i class="fas fa-laptop fa-3x text-primary mb-3"></i>
                    <h3 class="h4 mb-3">Online Tutoring</h3>
                    <p>Learn from anywhere with our virtual classroom platform, featuring interactive tools and resources.</p>
                    <ul class="list-unstyled text-start">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Virtual classroom</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Interactive tools</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Recorded sessions</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Subjects We Cover -->
    <div class="row mt-5">
        <div class="col-12">
            <h2 class="text-center mb-4">Subjects We Cover</h2>
            <div class="row">
                <div class="col-md-3 col-6 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-calculator fa-2x text-primary mb-3"></i>
                            <h4 class="h5">Mathematics</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-flask fa-2x text-primary mb-3"></i>
                            <h4 class="h5">Science</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-language fa-2x text-primary mb-3"></i>
                            <h4 class="h5">Languages</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-book fa-2x text-primary mb-3"></i>
                            <h4 class="h5">Humanities</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pricing Section -->
    <div class="row mt-5">
        <div class="col-12">
            <h2 class="text-center mb-4">Our Pricing</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <h3 class="h4">Basic</h3>
                            <h4 class="text-primary">$20/hour</h4>
                            <ul class="list-unstyled mt-3">
                                <li class="mb-2">One-on-One Sessions</li>
                                <li class="mb-2">Basic Learning Materials</li>
                                <li class="mb-2">Email Support</li>
                            </ul>
                            <button class="btn btn-primary mt-3">Get Started</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <h3 class="h4">Premium</h3>
                            <h4 class="text-primary">$30/hour</h4>
                            <ul class="list-unstyled mt-3">
                                <li class="mb-2">One-on-One Sessions</li>
                                <li class="mb-2">Premium Learning Materials</li>
                                <li class="mb-2">Priority Support</li>
                                <li class="mb-2">Progress Reports</li>
                            </ul>
                            <button class="btn btn-primary mt-3">Get Started</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <h3 class="h4">Group</h3>
                            <h4 class="text-primary">$15/hour</h4>
                            <ul class="list-unstyled mt-3">
                                <li class="mb-2">Group Sessions</li>
                                <li class="mb-2">Shared Learning Materials</li>
                                <li class="mb-2">Email Support</li>
                                <li class="mb-2">Group Activities</li>
                            </ul>
                            <button class="btn btn-primary mt-3">Get Started</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 