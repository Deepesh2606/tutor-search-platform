<?php
// db.php — Include DB connection
include('db.php');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Show toast if redirected with message
$toast_message = '';
if (isset($_GET['msg'])) {
    $toast_message = htmlspecialchars($_GET['msg']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if user exists in the database
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id']; // Start session for the user
            header("Location: index.php"); // Redirect to user dashboard
            exit();
        } else {
            $error = "❌ Invalid password.";
        }
    } else {
        $error = "❌ User not found.";
    }
}

// Include header after all header operations are done
include('header.php');
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="text-center mb-4">
            <i class="fas fa-user-graduate fa-3x mb-3" style="color: #1E3A8A;"></i>
            <h2 class="auth-title">Student Login</h2>
            <p class="text-muted">Welcome back! Please login to your account</p>
        </div>

        <form method="POST" id="loginForm" class="auth-form">
            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-envelope me-2"></i>Email Address
                </label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-lock me-2"></i>Password
                </label>
                <div class="input-group">
                    <input type="password" name="password" class="form-control" id="password" required>
                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary auth-btn">
                <i class="fas fa-sign-in-alt me-2"></i>Login
            </button>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger mt-3 text-center">
                    <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                </div>
            <?php endif; ?>
        </form>

        <div class="auth-footer text-center mt-4">
            <p class="mb-0">Don't have an account? 
                <a href="register.php" class="auth-link">
                    <i class="fas fa-user-plus me-1"></i>Register here
                </a>
            </p>
        </div>
    </div>
</div>

<!-- Toast Message -->
<?php if (!empty($toast_message)): ?>
<div class="toast-container">
    <div class="toast show">
        <div class="toast-body">
            <i class="fas fa-info-circle me-2"></i><?= $toast_message ?>
        </div>
    </div>
</div>
<?php endif; ?>

<style>/* General Auth Container Styling */
.auth-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: #f3f4f6;
    padding: 10px;
    box-sizing: border-box;
}

/* Auth Card Styling */
.auth-card {
    background: #ffffff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
}

/* Title Styling */
.auth-title {
    font-size: 24px;
    font-weight: bold;
    color: #1E3A8A;
}

/* Input Styling */
.auth-form .form-group {
    margin-bottom: 20px;
}

.auth-form .form-label {
    font-weight: 500;
    margin-bottom: 8px;
    display: block;
    color: #374151;
}

.auth-form .form-control {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #d1d5db;
    border-radius: 5px;
    font-size: 16px;
}

/* Input Group (password + toggle button) */
.auth-form .input-group {
    display: flex;
    align-items: center;
}

.auth-form .input-group .form-control {
    flex: 1;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
}

.auth-form .input-group .btn {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
}

/* Submit Button */
.auth-btn {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    font-weight: 600;
}

/* Error Alert */
.alert {
    font-size: 14px;
    padding: 10px 15px;
    margin-top: 15px;
}

/* Toast Styling */
.toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1055;
}

.toast {
    background-color: #2563eb;
    color: #fff;
    padding: 12px 20px;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

/* Auth Footer Link */
.auth-footer {
    margin-top: 25px;
    font-size: 14px;
}

/* Responsive Adjustments */
@media (max-width: 576px) {
    .auth-container {
        align-items: flex-start;
        padding-top: 30px;
        padding-bottom: 30px;
    }

    .auth-card {
        padding: 20px;
        box-shadow: none;
    }

    .auth-title {
        font-size: 20px;
    }

    .auth-form .form-control {
        font-size: 14px;
    }

    .auth-btn {
        font-size: 14px;
    }

    .toast-container {
        right: 10px;
        left: 10px;
    }
}

</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');

    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });
});
</script>

<?php include 'footer.php'; ?>
