<?php
ob_start(); // Start output buffering
include('db.php');
include('header.php');

// Check if user is logged in
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php?msg=Please login to submit a testimonial");
        exit;
    }
}
$user_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = $_POST['rating'];
    $content = $conn->real_escape_string($_POST['content']);
    
    // Insert testimonial into database
    $sql = "INSERT INTO testimonials (student_id, rating, content, status) VALUES (?, ?, ?, 'pending')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iis", $user_id, $rating, $content);
    
    if ($stmt->execute()) {
        $success_message = "Thank you for your testimonial! It will be reviewed and published soon.";
    } else {
        $error_message = "Error submitting testimonial. Please try again.";
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h2 class="text-center mb-4">Share Your Experience</h2>
                    
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success text-center">
                            <i class="fas fa-check-circle me-2"></i><?= $success_message ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger text-center">
                            <i class="fas fa-exclamation-circle me-2"></i><?= $error_message ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" class="testimonial-form">
                        <div class="mb-4">
                            <label class="form-label">Your Rating</label>
                            <div class="rating-input">
                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" name="rating" id="star<?= $i ?>" value="<?= $i ?>" required>
                                    <label for="star<?= $i ?>"><i class="fas fa-star"></i></label>
                                <?php endfor; ?>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Your Experience</label>
                            <textarea name="content" class="form-control" rows="5" placeholder="Share your experience with our tutoring service..." required></textarea>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg px-5">
                                <i class="fas fa-paper-plane me-2"></i>Submit Testimonial
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.rating-input {
    display: flex;
    flex-direction: row-reverse;
    justify-content: center;
    gap: 0.5rem;
}

.rating-input input {
    display: none;
}

.rating-input label {
    font-size: 2rem;
    color: #ddd;
    cursor: pointer;
    transition: color 0.3s;
}

.rating-input input:checked ~ label,
.rating-input label:hover,
.rating-input label:hover ~ label {
    color: #ffc107;
}

.testimonial-form textarea {
    resize: none;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 1rem;
    transition: all 0.3s;
}

.testimonial-form textarea:focus {
    border-color: #1E3A8A;
    box-shadow: 0 0 0 0.2rem rgba(30, 58, 138, 0.15);
}
</style>

<?php include('footer.php'); ?> 