<?php
session_start();
include 'db.php';

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch tutors from the database
$tutor_query = "SELECT * FROM users WHERE role = 'tutor'";
$tutor_result = $conn->query($tutor_query);

// Handle tutor actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $tutor_id = $_GET['id'];
    $action = $_GET['action'];
    
    switch($action) {
        case 'approve':
            $update_query = "UPDATE users SET status = 'approved' WHERE id = ?";
            $message = 'Tutor approved successfully!';
            break;
        case 'ban':
            $update_query = "UPDATE users SET status = 'banned' WHERE id = ?";
            $message = 'Tutor banned successfully!';
            break;
        case 'unban':
            $update_query = "UPDATE users SET status = 'pending' WHERE id = ?";
            $message = 'Tutor unbanned successfully!';
            break;
    }
    
    if (isset($update_query)) {
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param('i', $tutor_id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = $message;
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = 'Error performing action!';
            $_SESSION['message_type'] = 'error';
        }
    }
    
    header("Location: dashboard.php");
    exit();
}

// Fetch total users and tutors count for dashboard
$total_users_query = "SELECT COUNT(*) as total_users FROM users WHERE role = 'student'";
$total_users_result = $conn->query($total_users_query);
$total_users = $total_users_result->fetch_assoc()['total_users'];

$total_tutors_query = "SELECT COUNT(*) as total_tutors FROM users WHERE role = 'tutor'";
$total_tutors_result = $conn->query($total_tutors_query);
$total_tutors = $total_tutors_result->fetch_assoc()['total_tutors'];

// Fetch counts for different tutor statuses
$approved_tutors_query = "SELECT COUNT(*) as count FROM users WHERE role = 'tutor' AND status = 'approved'";
$approved_tutors = $conn->query($approved_tutors_query)->fetch_assoc()['count'];

$pending_tutors_query = "SELECT COUNT(*) as count FROM users WHERE role = 'tutor' AND status = 'pending'";
$pending_tutors = $conn->query($pending_tutors_query)->fetch_assoc()['count'];

$banned_tutors_query = "SELECT COUNT(*) as count FROM users WHERE role = 'tutor' AND status = 'banned'";
$banned_tutors = $conn->query($banned_tutors_query)->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --warning-color: #f59e0b;
            --background-dark: #0f172a;
            --card-background: #1e293b;
            --text-color: #f8fafc;
            --border-color: #334155;
        }

        body {
            background-color: var(--background-dark);
            color: var(--text-color);
            min-height: 100vh;
            padding-bottom: 2rem;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        h1.mb-4 {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 2rem !important;
            padding-left: 0.5rem;
        }

        .card {
            background-color: var(--card-background);
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
            transition: transform 0.2s;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .card-body {
            padding: 1.5rem;
        }

        .card-title {
            font-size: 1rem;
            color: var(--text-color);
            margin-bottom: 0.75rem;
            font-weight: 500;
        }

        .card-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0;
            color: var(--text-color);
        }

        .table-responsive {
            margin-top: 1rem;
            border-radius: 0.75rem;
            overflow: hidden;
        }

        .table {
            margin-bottom: 0;
        }

        .table th {
            background-color: var(--border-color);
            color: var(--text-color);
            font-weight: 600;
            border-bottom: none;
            padding: 1rem;
            white-space: nowrap;
        }

        .table td {
            padding: 1rem;
            vertical-align: middle;
            border-color: var(--border-color);
            color: var(--text-color);
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 2rem;
            font-size: 0.875rem;
            font-weight: 600;
            display: inline-block;
            text-align: center;
            min-width: 100px;
        }

        .action-btn {
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            font-weight: 500;
            transition: all 0.2s;
            min-width: 100px;
            text-align: center;
            margin: 0.25rem;
        }

        .alert {
            margin-bottom: 2rem;
            padding: 1rem 1.5rem;
        }

        .modal-content {
            padding: 1rem;
        }

        .modal-header {
            padding: 1rem 1.5rem;
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-footer {
            padding: 1rem 1.5rem;
            gap: 0.5rem;
        }

        /* Quick Actions Cards */
        .quick-actions .card {
            padding: 1.5rem;
            height: 100%;
            display: flex;
            align-items: center;
        }

        .quick-actions .card .d-flex {
            width: 100%;
            min-height: 60px;
        }

        .quick-actions .card i {
            font-size: 1.5rem;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .quick-actions .card div {
            flex: 1;
        }

        .quick-actions .card small {
            color: rgba(255, 255, 255, 0.85) !important;
            opacity: 1;
            display: block;
            white-space: normal;
            line-height: 1.4;
        }

        .text-muted {
            color: rgba(255, 255, 255, 0.85) !important;
        }

        .quick-actions .card-title {
            margin-bottom: 0.25rem;
            white-space: nowrap;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }

            h1.mb-4 {
                font-size: 1.5rem;
                margin-bottom: 1.5rem !important;
            }

            .card-value {
                font-size: 1.5rem;
            }

            .table td, .table th {
                padding: 0.75rem;
            }

            .action-btn {
                min-width: auto;
                padding: 0.4rem 0.8rem;
            }
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
    <!-- Display Success or Error Message -->
    <?php
    if (isset($_SESSION['message'])) {
        $alert_class = $_SESSION['message_type'] === 'error' ? 'alert-error' : 'alert-success';
        echo '<div class="alert ' . $alert_class . ' alert-dismissible fade show" role="alert">
                ' . $_SESSION['message'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
    ?>

    <h1 class="mb-4">Admin Dashboard</h1>

    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Total Users</h6>
                <p class="card-value"><?php echo $total_users; ?></p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Total Tutors</h6>
                <p class="card-value"><?php echo $total_tutors; ?></p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Approved Tutors</h6>
                <p class="card-value"><?php echo $approved_tutors; ?></p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Pending Tutors</h6>
                <p class="card-value"><?php echo $pending_tutors; ?></p>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row g-4 mb-4 quick-actions">
        <div class="col-md-3">
            <a href="tutors.php" class="text-decoration-none">
                <div class="card p-3 hover-shadow">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-chalkboard-teacher fa-2x me-3" style="color: var(--primary-color);"></i>
                        <div>
                            <h6 class="card-title mb-0">Manage Tutors</h6>
                            <small class="text-muted">View and manage tutor accounts</small>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3">
            <a href="students.php" class="text-decoration-none">
                <div class="card p-3 hover-shadow">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-user-graduate fa-2x me-3" style="color: var(--primary-color);"></i>
                        <div>
                            <h6 class="card-title mb-0">Manage Students</h6>
                            <small class="text-muted">View and manage student accounts</small>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3">
            <a href="subjects.php" class="text-decoration-none">
                <div class="card p-3 hover-shadow">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-book fa-2x me-3" style="color: var(--primary-color);"></i>
                        <div>
                            <h6 class="card-title mb-0">Manage Subjects</h6>
                            <small class="text-muted">Add and manage subjects</small>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3">
            <a href="questions.php" class="text-decoration-none">
                <div class="card p-3 hover-shadow">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-question-circle fa-2x me-3" style="color: var(--primary-color);"></i>
                        <div>
                            <h6 class="card-title mb-0">Manage Questions</h6>
                            <small class="text-muted">View and manage Q&A section</small>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title mb-4">Tutors List</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($tutor_result->num_rows > 0) {
                            while ($tutor = $tutor_result->fetch_assoc()) {
                                $status_class = 'status-' . $tutor['status'];
                                echo "<tr>
                                        <td>" . $tutor['id'] . "</td>
                                        <td>" . $tutor['name'] . "</td>
                                        <td>" . $tutor['email'] . "</td>
                                        <td><span class='status-badge $status_class'>" . ucfirst($tutor['status']) . "</span></td>
                                        <td>";
                                
                                if ($tutor['status'] == 'pending') {
                                    echo "<button class='btn btn-approve action-btn me-2' onclick='confirmAction(\"approve\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-check me-1'></i>Approve
                                          </button>
                                          <button class='btn btn-ban action-btn' onclick='confirmAction(\"ban\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-ban me-1'></i>Ban
                                          </button>";
                                } elseif ($tutor['status'] == 'approved') {
                                    echo "<button class='btn btn-ban action-btn' onclick='confirmAction(\"ban\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-ban me-1'></i>Ban
                                          </button>";
                                } elseif ($tutor['status'] == 'banned') {
                                    echo "<button class='btn btn-unban action-btn' onclick='confirmAction(\"unban\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-unlock me-1'></i>Unban
                                          </button>";
                                }
                                
                                echo "</td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>No tutors found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Action</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="modalMessage"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmAction">Confirm</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentAction = '';
let currentId = 0;

function confirmAction(action, id) {
    currentAction = action;
    currentId = id;
    
    const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));
    const message = document.getElementById('modalMessage');
    const confirmBtn = document.getElementById('confirmAction');
    
    let actionText = '';
    switch(action) {
        case 'approve':
            actionText = 'approve this tutor';
            confirmBtn.className = 'btn btn-success';
            break;
        case 'ban':
            actionText = 'ban this tutor';
            confirmBtn.className = 'btn btn-danger';
            break;
        case 'unban':
            actionText = 'unban this tutor';
            confirmBtn.className = 'btn btn-warning';
            break;
    }
    
    message.textContent = `Are you sure you want to ${actionText}?`;
    modal.show();
}

document.getElementById('confirmAction').addEventListener('click', function() {
    window.location.href = `dashboard.php?action=${currentAction}&id=${currentId}`;
});
</script>

</body>
</html>
