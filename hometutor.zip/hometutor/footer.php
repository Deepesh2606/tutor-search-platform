<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Quick Links -->
            <div class="col-6 col-md-3">
                <h5 class="mb-3">Quick Links</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="index.php" class="text-white text-decoration-none">Home</a></li>
                    <li class="mb-2"><a href="tutors.php" class="text-white text-decoration-none">Find Tutors</a></li>
                    <li class="mb-2"><a href="qna.php" class="text-white text-decoration-none">Q&A</a></li>
                </ul>
            </div>

            <!-- Contact Info -->
            <div class="col-6 col-md-3">
                <h5 class="mb-3">Contact Us</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="fas fa-phone me-2"></i> +91 8847443583</li>
                    <li class="mb-2"><i class="fas fa-envelope me-2"></i> deepeshsingh260@gmail.com</li>
                    <li class="mb-2"><i class="fas fa-map-marker-alt me-2"></i> Punjab , India</li>
                </ul>
            </div>

            <!-- Social Media -->
            <div class="col-12 col-md-6 text-center text-md-end">
                <div class="social-icons d-flex justify-content-center justify-content-md-end mb-3">
                    <a href="#" class="text-white me-2" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-white me-2" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-white me-2" target="_blank"><i class="fab fa-linkedin"></i></a>
                </div>
                <p class="mb-0 small">&copy; <?php echo date('Y'); ?> TutorAtHome. All Rights Reserved.</p>
            </div>
        </div>
    </div>

    <!-- Back to Top Button -->
    <button id="backToTop" class="btn btn-primary back-to-top" title="Go to top">
        <i class="fas fa-arrow-up"></i>
    </button>
</footer>

<!-- Bootstrap JS (with Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>

<!-- Font Awesome -->
<script src="https://kit.fontawesome.com/a076d05399.js"></script>

<!-- Custom styles -->
<style>
    footer {
        background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
    }

    footer a:hover {
        color: #FFD700 !important;
        text-decoration: none;
        transform: translateX(5px);
        transition: all 0.3s ease;
    }

    .social-icons a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.1);
        margin-right: 10px;
        transition: all 0.3s ease;
        text-decoration: none;
    }

    .social-icons a i {
        font-size: 18px;
        line-height: 1;
    }

    .social-icons a:hover {
        background: #FFD700;
        color: #000 !important;
        transform: translateY(-5px);
    }

    .back-to-top {
        position: fixed;
        bottom: 20px;
        right: 20px;
        display: none;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        z-index: 99;
    }

    .newsletter-form .form-control {
        border-radius: 25px 0 0 25px;
        border: none;
        padding: 10px 20px;
    }

    .newsletter-form .btn {
        border-radius: 0 25px 25px 0;
        padding: 10px 20px;
    }

    @media (max-width: 768px) {
        footer {
            padding: 2rem 0;
        }

        .col-6 {
            margin-bottom: 2rem;
        }

        .social-icons {
            margin-bottom: 1.5rem;
        }

        .social-icons a {
            width: 35px;
            height: 35px;
        }

        .social-icons a i {
            font-size: 16px;
        }

        .newsletter-form .form-control,
        .newsletter-form .btn {
            padding: 8px 15px;
        }

        .back-to-top {
            width: 40px;
            height: 40px;
            bottom: 15px;
            right: 15px;
        }
    }

    @media (max-width: 576px) {
        footer {
            padding: 1.5rem 0;
        }

        .col-6 {
            margin-bottom: 1.5rem;
        }

        h5 {
            font-size: 1.1rem;
        }

        .social-icons a {
            width: 30px;
            height: 30px;
        }

        .social-icons a i {
            font-size: 14px;
        }
    }
</style>

<!-- Back to Top Button Script -->
<script>
    window.onscroll = function() {
        scrollFunction();
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("backToTop").style.display = "block";
        } else {
            document.getElementById("backToTop").style.display = "none";
        }
    }

    document.getElementById("backToTop").addEventListener("click", function() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    });
</script>
