<?php
include 'db.php';

if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$tutor_id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT supporting_document FROM tutor_details WHERE user_id = ?");
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Tutor not found.");
}

$tutor = $result->fetch_assoc();

if (!empty($tutor['supporting_document'])) {
    // Encode spaces and special characters in the filename
    $filename = rawurlencode($tutor['supporting_document']);
    $url = "http://localhost/hometutor/img/supporting_documents/" . $filename;
    header("Location: $url");
    exit();
} else {
    die("No supporting document uploaded.");
}
