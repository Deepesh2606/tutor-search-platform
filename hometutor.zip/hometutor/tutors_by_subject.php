<?php
include("db.php");
session_start();
include 'header.php';

// Fetch all unique subjects
$subjects_query = "SELECT DISTINCT subject_expertise FROM tutor_details ORDER BY subject_expertise ASC";
$subjects_result = $conn->query($subjects_query);

// Get current user's location if logged in
$user_latitude = $user_longitude = null;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_stmt = $conn->prepare("SELECT latitude, longitude FROM users WHERE id = ?");
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    if ($user_result->num_rows == 1) {
        $user_row = $user_result->fetch_assoc();
        $user_latitude = $user_row['latitude'];
        $user_longitude = $user_row['longitude'];
    }
}
?>

<div class="container py-5">
    <h2 class="text-center mb-5">Tutors by Subject</h2>
    
    <?php
    if ($subjects_result->num_rows > 0) {
        while ($subject_row = $subjects_result->fetch_assoc()) {
            $subject = $subject_row['subject_expertise'];
            
            // Fetch tutors for this subject
            $tutors_query = "
                SELECT td.*, u.latitude, u.longitude, u.name, u.profile_picture, u.phone, u.status
                FROM tutor_details td
                JOIN users u ON td.user_id = u.id
                WHERE td.subject_expertise = ? AND u.status = 'approved'
                ORDER BY u.name ASC
            ";
            $tutors_stmt = $conn->prepare($tutors_query);
            $tutors_stmt->bind_param("s", $subject);
            $tutors_stmt->execute();
            $tutors_result = $tutors_stmt->get_result();
            
            if ($tutors_result->num_rows > 0) {
                ?>
                <div class="subject-section mb-5">
                    <h3 class="mb-4"><?= htmlspecialchars($subject) ?></h3>
                    <div class="row g-4">
                        <?php
                        while ($tutor = $tutors_result->fetch_assoc()) {
                            $profile_picture = $tutor['profile_picture'] ? 'img/profilepic/' . htmlspecialchars($tutor['profile_picture']) : 'img/default-profile.png';
                            
                            // Calculate distance if user location is available
                            $distance = null;
                            if ($user_latitude && $user_longitude && $tutor['latitude'] && $tutor['longitude']) {
                                $distance = 6371 * acos(
                                    cos(deg2rad($user_latitude)) * cos(deg2rad($tutor['latitude'])) *
                                    cos(deg2rad($tutor['longitude']) - deg2rad($user_longitude)) +
                                    sin(deg2rad($user_latitude)) * sin(deg2rad($tutor['latitude']))
                                );
                                $distance = round($distance, 2);
                            }
                            ?>
                            <div class="col-md-4">
                                <div class="card h-100 border-0 shadow-sm hover-shadow transition-all">
                                    <div class="card-body p-4 text-center">
                                        <img src="<?= $profile_picture ?>" alt="Profile Picture" class="rounded-circle mb-4" style="width: 120px; height: 120px; object-fit: cover; border: 4px solid #f8f9fa;">
                                        <h5 class="card-title fw-bold mb-3"><?= htmlspecialchars($tutor['name']) ?></h5>
                                        <div class="text-muted mb-3">
                                            <p class="mb-2"><i class="fas fa-graduation-cap me-2"></i><strong>Classes:</strong> <?= htmlspecialchars($tutor['teaching_levels']) ?></p>
                                            <p class="mb-2"><i class="fas fa-map-marker-alt me-2"></i><strong>Distance:</strong> 
                                                <?php 
                                                if ($distance !== null) {
                                                    echo $distance . ' KM';
                                                } else {
                                                    echo 'Location not available';
                                                }
                                                ?>
                                            </p>
                                            <p class="mb-3"><i class="fas fa-certificate me-2"></i><strong>Qualification:</strong> <?= htmlspecialchars($tutor['qualifications']) ?></p>
                                        </div>

                                        <?php if (isset($_SESSION['user_id'])): ?>
                                            <form action="send_request.php" method="post" class="mt-auto">
                                                <input type="hidden" name="tutor_id" value="<?= $tutor['user_id'] ?>">
                                                <input type="hidden" name="student_id" value="<?= $_SESSION['user_id'] ?>">
                                                <input type="hidden" name="tutor_phone" value="<?= isset($tutor['phone']) ? $tutor['phone'] : '' ?>">
                                                <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                                                    <i class="fas fa-paper-plane me-2"></i>Send Request
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <a href="login.php" class="btn btn-primary w-100 py-2 fw-semibold">
                                                <i class="fas fa-sign-in-alt me-2"></i>Login to Contact
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
                <?php
            }
        }
    } else {
        echo '<div class="alert alert-info text-center">No tutors found for any subject.</div>';
    }
    ?>
</div>

<style>
.hover-shadow {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-shadow:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
}
.subject-section {
    padding: 2rem;
    background: #f8f9fa;
    border-radius: 1rem;
}
</style>

<?php include 'footer.php'; ?> 