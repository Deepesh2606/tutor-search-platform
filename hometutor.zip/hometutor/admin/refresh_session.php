<?php
session_start();
if (isset($_SESSION['admin_id'])) {
    // Just starting the session is enough to refresh it
    echo 'Session refreshed';
}