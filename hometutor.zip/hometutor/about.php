<?php include 'header.php'; ?>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="text-center mb-4">About TutorAtHome</h1>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Our Mission</h2>
                    <p class="lead">At TutorAtHome, we believe in making quality education accessible to everyone, anywhere, anytime.</p>
                    <p>We connect students with expert tutors who provide personalized learning experiences in the comfort of your home or online.</p>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Our Story</h2>
                    <p>Founded in 2024, TutorAtHome started with a simple idea: to make quality education more accessible and personalized. What began as a small team of passionate educators has grown into a platform connecting thousands of students with expert tutors across various subjects.</p>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Why Choose Us?</h2>
                    <ul class="list-unstyled">
                        <li class="mb-3"><i class="fas fa-check-circle text-primary me-2"></i> Expert tutors with verified credentials</li>
                        <li class="mb-3"><i class="fas fa-check-circle text-primary me-2"></i> Flexible scheduling options</li>
                        <li class="mb-3"><i class="fas fa-check-circle text-primary me-2"></i> Personalized learning plans</li>
                        <li class="mb-3"><i class="fas fa-check-circle text-primary me-2"></i> Safe and secure platform</li>
                        <li class="mb-3"><i class="fas fa-check-circle text-primary me-2"></i> Affordable pricing options</li>
                    </ul>
                </div>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h2 class="h4 mb-3">Our Team</h2>
                    <p>Our team consists of experienced educators, technologists, and support staff dedicated to providing the best learning experience for our students.</p>
                    <div class="row mt-4">
                        <div class="col-md-4 text-center mb-4">
                            <img src="https://via.placeholder.com/150" class="rounded-circle mb-3" alt="Team Member">
                            <h5 class="mb-1">John Doe</h5>
                            <p class="text-muted">Founder & CEO</p>
                        </div>
                        <div class="col-md-4 text-center mb-4">
                            <img src="https://via.placeholder.com/150" class="rounded-circle mb-3" alt="Team Member">
                            <h5 class="mb-1">Jane Smith</h5>
                            <p class="text-muted">Head of Education</p>
                        </div>
                        <div class="col-md-4 text-center mb-4">
                            <img src="https://via.placeholder.com/150" class="rounded-circle mb-3" alt="Team Member">
                            <h5 class="mb-1">Mike Johnson</h5>
                            <p class="text-muted">Technical Director</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 