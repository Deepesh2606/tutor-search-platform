<?php
session_start();
include 'db.php';
include 'header.php';

// Get logged-in user ID if any
$user_id = $_SESSION['user_id'] ?? null;

// Fetch all questions with user name
$questions = mysqli_query($conn, "SELECT q.*, u.name AS asked_by FROM questions q JOIN users u ON q.user_id = u.id ORDER BY q.created_at DESC");
?>

<style>
    .qa-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 30px 20px;
        background-color: #f8f9fa;
    }

    .qa-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 40px;
        padding-bottom: 20px;
        border-bottom: 2px solid #e0e0e0;
    }

    .qa-header h2 {
        color: #2c3e50;
        font-size: 2em;
        margin: 0;
        font-weight: 600;
    }

    .questions-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 30px;
    }

    .ask-question-btn {
        background-color: #4CAF50;
        color: white;
        padding: 12px 24px;
        text-decoration: none;
        border-radius: 8px;
        font-size: 1.1em;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        font-weight: 500;
    }

    .ask-question-btn:hover {
        background-color: #45a049;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    .question-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        padding: 25px;
        height: 100%;
        display: flex;
        flex-direction: column;
        transition: all 0.3s ease;
        border: 1px solid #e0e0e0;
    }

    .question-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 16px rgba(0,0,0,0.12);
    }

    .question-subject {
        font-size: 1.3em;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid #f0f0f0;
    }

    .question-content {
        color: #34495e;
        margin-bottom: 20px;
        line-height: 1.6;
        font-size: 1.1em;
        flex-grow: 1;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .question-meta {
        color: #7f8c8d;
        font-size: 0.95em;
        margin-bottom: 20px;
        font-style: italic;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .question-image {
        width: 100%;
        max-width: 800px;
        height: auto;
        object-fit: contain;
        border-radius: 8px;
        margin: 15px auto;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        background-color: white;
        padding: 15px;
        border: 1px solid #e0e0e0;
        display: block;
    }

    .answer-section {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 20px;
        margin-top: 20px;
        border-left: 4px solid #4CAF50;
    }

    .answer-content {
        color: #2c3e50;
        line-height: 1.6;
        margin-bottom: 15px;
        font-size: 1.1em;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .answer-meta {
        color: #7f8c8d;
        font-size: 0.95em;
        margin-bottom: 15px;
        font-style: italic;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .question-image, .answer-section img {
        width: 100%;
        max-width: 300px;
        height: auto;
        object-fit: cover;
        border-radius: 8px;
        margin: 10px 0;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        background-color: white;
        padding: 5px;
        border: 1px solid #e0e0e0;
        display: block;
    }

    .vote-section {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-top: 15px;
        padding-top: 15px;
        border-top: 1px solid #e0e0e0;
    }

    .vote-count {
        display: flex;
        align-items: center;
        gap: 5px;
        font-weight: 500;
        color: #2c3e50;
        font-size: 0.95em;
    }

    .vote-btn {
        display: flex;
        align-items: center;
        gap: 5px;
        color: #34495e;
        text-decoration: none;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 0.9em;
        transition: all 0.3s ease;
        background-color: #f8f9fa;
        border: 1px solid #e0e0e0;
    }

    .vote-btn:hover {
        background-color: #e9ecef;
        transform: translateY(-1px);
    }

    .vote-btn.like:hover {
        color: #28a745;
    }

    .vote-btn.dislike:hover {
        color: #dc3545;
    }
 

    .vote-btn:hover {
        background-color: #f0f0f0;
        color: #2c3e50;
        transform: translateY(-2px);
    }

    .action-buttons {
        display: flex;
        gap: 15px;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #e0e0e0;
    }

    .action-btn {
        padding: 10px 20px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 500;
        font-size: 1em;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .view-replies-btn {
        background-color: #007bff;
        color: white;
    }

    .view-replies-btn:hover {
        background-color: #0056b3;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    .reply-btn {
        background-color: #28a745;
        color: white;
    }

    .reply-btn:hover {
        background-color: #218838;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    @media (max-width: 768px) {
        .questions-grid {
            grid-template-columns: 1fr;
            gap: 20px;
        }
        
        .qa-container {
            padding: 20px 15px;
        }
        
        .question-card {
            padding: 20px;
        }
        
        .question-image {
            max-width: 100%;
            height: auto;
            padding: 10px;
        }
    }
</style>

<div class="qa-container">
    <div class="qa-header">
        <h2>Q&A Section</h2>
        <a href="ask-question.php" class="ask-question-btn">Ask a Question</a>
    </div>

    <div class="questions-grid">
        <?php while ($q = mysqli_fetch_assoc($questions)) { ?>
            <div class="question-card">
                <div class="question-subject"><?= htmlspecialchars($q['subject']) ?></div>
                <div class="question-content"><?= htmlspecialchars($q['question']) ?></div>
                <div class="question-meta">
                    Asked by: <?= $q['asked_by'] ?> on <?= $q['created_at'] ?>
                </div>

                <?php if ($q['image']) { ?>
                    <img src="<?= $q['image'] ?>" class="question-image" alt="Question image">
                <?php } ?>

                <?php
                $qid = $q['id'];
                // Update the SQL query in the answers section to include user's vote status
                $answers = mysqli_query($conn, "
                    SELECT a.*, u.name, 
                        (SELECT COUNT(*) FROM answer_votes WHERE answer_id = a.id AND vote_type = 'like') AS likes, 
                        (SELECT COUNT(*) FROM answer_votes WHERE answer_id = a.id AND vote_type = 'dislike') AS dislikes,
                        (SELECT vote_type FROM answer_votes WHERE answer_id = a.id AND user_id = '$user_id') AS user_vote
                    FROM answers a 
                    JOIN users u ON a.user_id = u.id 
                    WHERE question_id = '$qid' 
                    ORDER BY likes DESC LIMIT 1");

                $top_answer = mysqli_fetch_assoc($answers);

                if ($top_answer) {
                ?>
                    <div class="answer-section">
                        <div class="answer-content">
                            <strong>Answer by <?= $top_answer['name'] ?>:</strong><br>
                            <?= htmlspecialchars($top_answer['answer']) ?>
                        </div>
                        <?php if ($top_answer['image']) { ?>
                            <img src="<?= $top_answer['image'] ?>" class="question-image" alt="Answer image">
                        <?php } ?>
                        <div class="answer-meta"><?= $top_answer['created_at'] ?></div>

                        <!-- Update the vote section HTML -->
                        <div class="vote-section">
                            <span class="vote-count">
                                <i class="fas fa-thumbs-up"></i> <?= $top_answer['likes'] ?>
                            </span>
                            <span class="vote-count">
                                <i class="fas fa-thumbs-down"></i> <?= $top_answer['dislikes'] ?>
                            </span>
                            <?php if ($user_id): ?>
                                <?php
                                $liked = $top_answer['user_vote'] === 'like';
                                $disliked = $top_answer['user_vote'] === 'dislike';
                                ?>
                                <a href="vote.php?action=like&answer_id=<?= $top_answer['id'] ?>" 
                                   class="vote-btn like <?= $liked ? 'active' : '' ?>" 
                                   <?= $liked ? 'disabled' : '' ?>>
                                    <i class="fas fa-thumbs-up"></i> Like
                                </a>
                                <a href="vote.php?action=dislike&answer_id=<?= $top_answer['id'] ?>" 
                                   class="vote-btn dislike <?= $disliked ? 'active' : '' ?>"
                                   <?= $disliked ? 'disabled' : '' ?>>
                                    <i class="fas fa-thumbs-down"></i> Dislike
                                </a>
                            <?php else: ?>
                                <a href="login.php" class="vote-btn">
                                    <i class="fas fa-sign-in-alt"></i> Login to vote
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php } ?>

                <div class="action-buttons">
                    <a href="view-answers.php?question_id=<?= $q['id'] ?>" class="action-btn view-replies-btn">See All Replies</a>

                    <?php if ($user_id): ?>
                        <a href="submit-answer.php?question_id=<?= $q['id'] ?>" class="action-btn reply-btn">Reply</a>
                    <?php else: ?>
                        <a href="login.php?redirect=submit-answer.php?question_id=<?= $q['id'] ?>" class="action-btn reply-btn">Reply</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php include 'footer.php'; ?>

<!-- Add these styles -->
<style>
    .vote-btn.active {
        background-color: #e9ecef;
        cursor: default;
        pointer-events: none;
    }

    .vote-btn.like.active {
        color: #28a745;
        border-color: #28a745;
    }

    .vote-btn.dislike.active {
        color: #dc3545;
        border-color: #dc3545;
    }

    .vote-btn[disabled] {
        opacity: 0.7;
        cursor: not-allowed;
    }
</style>
