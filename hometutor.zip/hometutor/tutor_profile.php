<?php
ob_start();

session_start();

include('db.php');
include('tutor_header.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'tutor') {
    header('Location: tutor_login.php');
    exit();
}

$tutor_id = $_SESSION['user_id'];
$tutor = [];

$query = "
    SELECT u.id, u.name, u.email, u.profile_picture, u.address, u.status, u.phone, u.latitude, u.longitude, u.created_at,
           td.subject_expertise, td.qualifications, td.teaching_levels, td.supporting_document, td.rating, td.availability
    FROM users u
    LEFT JOIN tutor_details td ON u.id = td.user_id
    WHERE u.id = ? AND u.role = 'tutor'
";
$stmt = $conn->prepare($query);
if ($stmt === false) die('MySQL prepare error: ' . $conn->error);
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $tutor = $result->fetch_assoc();
} else {
    echo "Tutor not found.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_email = $_POST['email'];
    $new_phone = $_POST['phone'];
    $new_availability = $_POST['availability'];

    $profile_pic_filename = $tutor['profile_picture'];
    $supporting_doc_filename = $tutor['supporting_document'];

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $img_tmp = $_FILES['profile_picture']['tmp_name'];
        $img_name = time() . '_' . basename($_FILES['profile_picture']['name']);
        $img_dest = 'img/profilepic/' . $img_name;
        if (move_uploaded_file($img_tmp, $img_dest)) {
            $profile_pic_filename = $img_name;
        }
    }

    // Handle supporting document upload
    if (isset($_FILES['supporting_document']) && $_FILES['supporting_document']['error'] === UPLOAD_ERR_OK) {
        $doc_tmp = $_FILES['supporting_document']['tmp_name'];
        $doc_name = time() . '_' . basename($_FILES['supporting_document']['name']);
        $doc_dest = 'img/supporting_documents/' . $doc_name;
        if (move_uploaded_file($doc_tmp, $doc_dest)) {
            $supporting_doc_filename = $doc_name;
        }
    }

    // Update query
    $update_query = "
        UPDATE users u
        JOIN tutor_details td ON u.id = td.user_id
        SET u.email = ?, u.phone = ?, u.profile_picture = ?, td.availability = ?, td.supporting_document = ?
        WHERE u.id = ?
    ";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("sssssi", $new_email, $new_phone, $profile_pic_filename, $new_availability, $supporting_doc_filename, $tutor_id);

    if ($update_stmt->execute()) {
        header('Location: tutor_profile.php');
        exit();
    } else {
        echo "Failed to update profile.";
    }
}
?>

<!-- HTML below remains mostly unchanged except the form and inputs -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tutor Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
          body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f7fb;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .profile-container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .profile-picture {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .profile-info h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 500;
        }

        .profile-info p {
            margin: 5px 0;
            font-size: 16px;
        }

        .profile-location, .profile-bio, .profile-meta, .profile-details {
            margin-top: 20px;
        }

        h3 {
            font-size: 20px;
            margin-bottom: 10px;
        }

        p {
            font-size: 16px;
            line-height: 1.5;
        }

        a {
            color: #1E3A8A;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .edit-button {
            background-color: #1E3A8A;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
        }

        .edit-button:hover {
            background-color: #163B6D;
        }

        input[type="text"], select {
            padding: 8px;
            margin: 5px 0;
            width: 100%;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.875rem;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-banned {
            background: #f8d7da;
            color: #721c24;
        }

        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        .profile-container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .profile-picture {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
        }
        .edit-button {
            background-color: #1E3A8A;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
        }
        .edit-button:hover {
            background-color: #163B6D;
        }
        input[type="text"], input[type="file"], select {
            padding: 8px;
            margin: 5px 0;
            width: 100%;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.875rem;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-banned { background: #f8d7da; color: #721c24; }
        .status-approved { background: #d4edda; color: #155724; }
    </style>
</head>

<body>
<div class="profile-container">
    <h1>Tutor Profile</h1>
    <form action="tutor_profile.php" method="POST" enctype="multipart/form-data">
        <div class="profile-header">
            <img src="<?php echo $tutor['profile_picture'] ? 'img/profilepic/' . $tutor['profile_picture'] : 'img/profilepic/default-avatar.jpg'; ?>" class="profile-picture" alt="Profile">
            <div class="profile-info">
                <h2><?php echo htmlspecialchars($tutor['name']); ?></h2>
                <p><strong>Status:</strong>
                    <span class="status-badge status-<?php echo strtolower($tutor['status']); ?>"><?php echo htmlspecialchars($tutor['status']); ?></span>
                </p>
                <p><strong>Email:</strong> <input type="text" name="email" value="<?php echo htmlspecialchars($tutor['email']); ?>" required></p>
                <p><strong>Phone:</strong> <input type="text" name="phone" value="<?php echo htmlspecialchars($tutor['phone']); ?>" required></p>
                <p><strong>Availability:</strong>
                    <select name="availability" required>
                        <option value="Not provided" <?php echo $tutor['availability'] === 'Not provided' ? 'selected' : ''; ?>>Not provided</option>
                        <option value="Morning" <?php echo $tutor['availability'] === 'Morning' ? 'selected' : ''; ?>>Morning</option>
                        <option value="Afternoon" <?php echo $tutor['availability'] === 'Afternoon' ? 'selected' : ''; ?>>Afternoon</option>
                        <option value="Evening" <?php echo $tutor['availability'] === 'Evening' ? 'selected' : ''; ?>>Evening</option>
                        <option value="Anytime" <?php echo $tutor['availability'] === 'Anytime' ? 'selected' : ''; ?>>Anytime</option>
                    </select>
                </p>
                <p><strong>Update Profile Picture:</strong><br>
                    <input type="file" name="profile_picture" accept="image/*">
                </p>
                <p><strong>Update Supporting Document (PDF or JPG):</strong><br>
                    <input type="file" name="supporting_document" accept=".pdf,.jpg,.jpeg,.png">
                </p>
                <button type="submit" class="edit-button">Update</button>
            </div>
        </div>

        <div class="profile-location">
            <h3>Location</h3>
            <p><strong>Latitude:</strong> <?php echo htmlspecialchars($tutor['latitude']); ?></p>
            <p><strong>Longitude:</strong> <?php echo htmlspecialchars($tutor['longitude']); ?></p>
        </div>

        <div class="profile-bio">
            <h3>Address</h3>
            <p><?php echo $tutor['address'] ? htmlspecialchars($tutor['address']) : 'Address not provided'; ?></p>
        </div>

        <div class="profile-details">
            <h3>Tutor Details</h3>
            <p><strong>Subject Expertise:</strong> <?php echo htmlspecialchars($tutor['subject_expertise']); ?></p>
            <p><strong>Qualifications:</strong> <?php echo htmlspecialchars($tutor['qualifications']); ?></p>
            <p><strong>Teaching Levels:</strong> <?php echo htmlspecialchars($tutor['teaching_levels']); ?></p>
            <p><strong>Supporting Document:</strong>
                <?php if ($tutor['supporting_document']): ?>
                    <a href="img/supporting_documents/<?php echo $tutor['supporting_document']; ?>" target="_blank">View Document</a>
                <?php else: ?>
                    Not provided
                <?php endif; ?>
            </p>
            <p><strong>Rating:</strong> <?php echo $tutor['rating'] ? $tutor['rating'] : 'Not rated yet'; ?></p>
        </div>

        <div class="profile-meta">
            <h3>Profile Created</h3>
            <p><?php echo date('F j, Y', strtotime($tutor['created_at'])); ?></p>
        </div>
    </form>
</div>
</body>
</html>
