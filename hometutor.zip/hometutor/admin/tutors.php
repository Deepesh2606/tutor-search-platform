<?php
session_start();
include 'db.php';

// Check admin login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Handle tutor actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $tutor_id = $_GET['id'];
    $action = $_GET['action'];
    
    switch($action) {
        case 'approve':
            $update_query = "UPDATE users SET status = 'approved' WHERE id = ?";
            $message = 'Tutor approved successfully!';
            break;
        case 'ban':
            $update_query = "UPDATE users SET status = 'banned' WHERE id = ?";
            $message = 'Tutor banned successfully!';
            break;
        case 'unban':
            $update_query = "UPDATE users SET status = 'pending' WHERE id = ?";
            $message = 'Tutor unbanned successfully!';
            break;
    }
    
    if (isset($update_query)) {
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param('i', $tutor_id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = $message;
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = 'Error performing action!';
            $_SESSION['message_type'] = 'error';
        }
    }
    
    header("Location: tutors.php");
    exit();
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Build query
$query = "SELECT * FROM users WHERE role = 'tutor'";
$params = [];
$types = "";

if ($status_filter !== 'all') {
    $query .= " AND status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if (!empty($search_query)) {
    $query .= " AND (name LIKE ? OR email LIKE ?)";
    $search_param = "%$search_query%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

$query .= " ORDER BY created_at DESC";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$tutor_result = $stmt->get_result();

// Get counts for different statuses
$total_tutors = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'tutor'")->fetch_assoc()['count'];
$approved_tutors = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'tutor' AND status = 'approved'")->fetch_assoc()['count'];
$pending_tutors = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'tutor' AND status = 'pending'")->fetch_assoc()['count'];
$banned_tutors = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'tutor' AND status = 'banned'")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutors Management - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<div class="container">
    <!-- Display Success or Error Message -->
    <?php
    if (isset($_SESSION['message'])) {
        $alert_class = $_SESSION['message_type'] === 'error' ? 'alert-error' : 'alert-success';
        echo '<div class="alert ' . $alert_class . ' alert-dismissible fade show" role="alert">
                ' . $_SESSION['message'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
    ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Tutors Management</h1>
        <div class="d-flex gap-2">
            <form class="d-flex" method="GET">
                <input type="text" name="search" class="form-control me-2" placeholder="Search tutors..." value="<?php echo htmlspecialchars($search_query); ?>">
                <select name="status" class="form-select me-2" style="width: auto;">
                    <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Status</option>
                    <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="banned" <?php echo $status_filter === 'banned' ? 'selected' : ''; ?>>Banned</option>
                </select>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search me-1"></i>Search
                </button>
            </form>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Total Tutors</h6>
                <p class="card-value"><?php echo $total_tutors; ?></p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Approved Tutors</h6>
                <p class="card-value"><?php echo $approved_tutors; ?></p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Pending Tutors</h6>
                <p class="card-value"><?php echo $pending_tutors; ?></p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-3">
                <h6 class="card-title">Banned Tutors</h6>
                <p class="card-value"><?php echo $banned_tutors; ?></p>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($tutor_result->num_rows > 0) {
                            while ($tutor = $tutor_result->fetch_assoc()) {
                                $status_class = 'status-' . $tutor['status'];
                                echo "<tr>
                                        <td>" . $tutor['id'] . "</td>
                                        <td>" . $tutor['name'] . "</td>
                                        <td>" . $tutor['email'] . "</td>
                                        <td>" . ($tutor['phone'] ?? 'N/A') . "</td>
                                        <td><span class='status-badge $status_class'>" . ucfirst($tutor['status']) . "</span></td>
                                        <td>" . date('M d, Y', strtotime($tutor['created_at'])) . "</td>
                                        <td>
                                            <div class='d-flex gap-2'>
                                                <button class='btn btn-info action-btn' onclick='viewTutor(" . $tutor['id'] . ")'>
                                                    <i class='fas fa-eye me-1'></i>View
                                                </button>";
                                
                                if ($tutor['status'] == 'pending') {
                                    echo "<button class='btn btn-approve action-btn' onclick='confirmAction(\"approve\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-check me-1'></i>Approve
                                          </button>
                                          <button class='btn btn-ban action-btn' onclick='confirmAction(\"ban\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-ban me-1'></i>Ban
                                          </button>";
                                } elseif ($tutor['status'] == 'approved') {
                                    echo "<button class='btn btn-ban action-btn' onclick='confirmAction(\"ban\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-ban me-1'></i>Ban
                                          </button>";
                                } elseif ($tutor['status'] == 'banned') {
                                    echo "<button class='btn btn-unban action-btn' onclick='confirmAction(\"unban\", " . $tutor['id'] . ")'>
                                            <i class='fas fa-unlock me-1'></i>Unban
                                          </button>";
                                }
                                
                                echo "
                                    </div>
                                  </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>No tutors found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm Action</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p id="confirmationMessage">Are you sure you want to proceed?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <a href="#" id="confirmActionBtn" class="btn btn-primary">Yes, Confirm</a>
      </div>
    </div>
  </div>
</div>

<script>
// Confirm action handler
function confirmAction(action, id) {
  let message = '';
  if (action === 'approve') {
    message = 'Are you sure you want to approve this tutor?';
  } else if (action === 'ban') {
    message = 'Are you sure you want to ban this tutor?';
  } else if (action === 'unban') {
    message = 'Are you sure you want to unban this tutor?';
  }
  document.getElementById('confirmationMessage').innerText = message;
  document.getElementById('confirmActionBtn').href = `tutors.php?action=${action}&id=${id}`;
  const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));
  modal.show();
}

// Redirect to view page (You can customize this to your view-tutor.php)
function viewTutor(id) {
  window.location.href = `view-tutor.php?id=${id}`;
}
</script>

<style>
.status-badge {
  padding: 0.3em 0.6em;
  border-radius: 5px;
  font-size: 0.85rem;
  font-weight: 500;
  color: #fff;
}
.status-approved {
  background-color: #28a745;
}
.status-pending {
  background-color: #ffc107;
  color: #000;
}
.status-banned {
  background-color: #dc3545;
}
.action-btn {
  font-size: 0.85rem;
}
.btn-approve {
  background-color: #198754;
  color: #fff;
}
.btn-ban {
  background-color: #dc3545;
  color: #fff;
}
.btn-unban {
  background-color: #0d6efd;
  color: #fff;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>