<?php
session_start();
include 'db.php'; // your database connection file

// If already logged in, redirect to admin dashboard
if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Rate limiting
$max_attempts = 5;
$lockout_time = 15 * 60; // 15 minutes
$ip = $_SERVER['REMOTE_ADDR'];

if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt'] = 0;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid request!";
    } else {
        // Check rate limiting
        if ($_SESSION['login_attempts'] >= $max_attempts) {
            $time_left = $lockout_time - (time() - $_SESSION['last_attempt']);
            if ($time_left > 0) {
                $error = "Too many attempts. Please try again in " . ceil($time_left / 60) . " minutes.";
            } else {
                $_SESSION['login_attempts'] = 0;
            }
        }

        if (empty($error)) {
            $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
            $password = $_POST['password'];
            $remember = isset($_POST['remember']) ? true : false;

            // Fetch admin from database
            $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ? AND role = 'admin' LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $admin = $result->fetch_assoc();

                // Verify password
                if (password_verify($password, $admin['password'])) {
                    // Reset login attempts on successful login
                    $_SESSION['login_attempts'] = 0;
                    
                    // Set session
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_name'] = $admin['name'];

                    // Set remember me cookie if requested
                    if ($remember) {
                        $token = bin2hex(random_bytes(32));
                        $expiry = time() + (30 * 24 * 60 * 60); // 30 days
                        setcookie('remember_token', $token, $expiry, '/', '', true, true);
                        
                        // Store token in database
                        $stmt = $conn->prepare("UPDATE users SET remember_token = ?, remember_token_expiry = ? WHERE id = ?");
                        $stmt->bind_param("ssi", $token, date('Y-m-d H:i:s', $expiry), $admin['id']);
                        $stmt->execute();
                    }

                    header("Location: dashboard.php");
                    exit();
                } else {
                    $_SESSION['login_attempts']++;
                    $_SESSION['last_attempt'] = time();
                    $error = "Invalid credentials!";
                }
            } else {
                $_SESSION['login_attempts']++;
                $_SESSION['last_attempt'] = time();
                $error = "Invalid credentials!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - E-Learning</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --background-dark: #0f172a;
            --card-background: #1e293b;
            --text-color: #f8fafc;
            --error-color: #ef4444;
            --input-background: #334155;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--background-dark);
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container { 
            width: 100%;
            max-width: 400px;
            margin: 20px;
            padding: 2rem;
            background: var(--card-background);
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        h2 { 
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 1.875rem;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 1.25rem;
            position: relative;
        }

        .input-group {
            position: relative;
        }

        input[type="email"], 
        input[type="password"] { 
            width: 100%;
            padding: 0.75rem 1rem;
            padding-right: 2.5rem;
            margin: 0.5rem 0;
            border: 1px solid var(--input-background);
            border-radius: 0.5rem;
            background: var(--input-background);
            color: var(--text-color);
            font-size: 1rem;
            transition: border-color 0.2s;
        }

        input[type="email"]:focus, 
        input[type="password"]:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .toggle-password {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-color);
            cursor: pointer;
            opacity: 0.7;
        }

        .toggle-password:hover {
            opacity: 1;
        }

        .remember-me {
            display: flex;
            align-items: center;
            margin-bottom: 1.25rem;
        }

        .remember-me input {
            margin-right: 0.5rem;
        }

        input[type="submit"] { 
            width: 100%;
            background: var(--primary-color);
            border: none;
            color: var(--text-color);
            padding: 0.75rem;
            border-radius: 0.5rem;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: background-color 0.2s;
        }

        input[type="submit"]:hover { 
            background: var(--primary-hover);
        }

        .error { 
            color: var(--error-color);
            text-align: center;
            margin-bottom: 1rem;
            padding: 0.5rem;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 0.5rem;
        }

        @media (max-width: 480px) {
            .login-container {
                margin: 1rem;
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>

    <?php 
    if(isset($_SESSION['message'])) {
        echo "<p class='error'>" . $_SESSION['message'] . "</p>";
        unset($_SESSION['message']);
    }
    if($error != "") { 
        echo "<p class='error'>$error</p>"; 
    } 
    ?>

    <form action="" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        
        <div class="form-group">
            <div class="input-group">
                <input type="email" name="email" placeholder="Admin Email" required>
            </div>
        </div>

        <div class="form-group">
            <div class="input-group">
                <input type="password" name="password" id="password" placeholder="Password" required>
                <button type="button" class="toggle-password" onclick="togglePassword()">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
        </div>

        <div class="remember-me">
            <input type="checkbox" name="remember" id="remember">
            <label for="remember">Remember Me</label>
        </div>

        <input type="submit" value="Login">
    </form>

    <div class="text-center mt-3">
        <a href="../index.php" class="btn btn-light">
            <i class="fas fa-home"></i> Go to Home Page
        </a>
    </div>
</div>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const icon = document.querySelector('.toggle-password i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

</body>
</html>
