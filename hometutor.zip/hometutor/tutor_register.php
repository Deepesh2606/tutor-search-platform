<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name              = $_POST['name'];
    $email             = $_POST['email'];
    $phone             = $_POST['phone']; // Add phone field
    $password          = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $subject_expertise = $_POST['subject_expertise'];
    $qualifications    = $_POST['qualification'];
    $teaching_levels = isset($_POST['teaching_classes']) ? implode(", ", $_POST['teaching_classes']) : '';
    $role              = 'tutor';
    $latitude          = $_POST['latitude'];
    $longitude         = $_POST['longitude'];
    $status            = 'pending'; // Setting the default status to 'pending'

    // Insert tutor into the users table
    $sql = "INSERT INTO users (name, email, phone, password, role, latitude, longitude, status) 
            VALUES ('$name', '$email', '$phone', '$password', '$role', '$latitude', '$longitude', '$status')";

    if ($conn->query($sql) === TRUE) {
        $user_id = $conn->insert_id;

        // Insert tutor details into tutor_details table
        $sql_tutor_details = "INSERT INTO tutor_details (user_id, subject_expertise, teaching_levels, qualifications) 
                              VALUES ('$user_id', '$subject_expertise', '$teaching_levels', '$qualifications')";

        if ($conn->query($sql_tutor_details) === TRUE) {
            $message = "✅ Tutor registration successful! Status: Pending approval.";
        } else {
            $message = "❌ Error in saving tutor details: " . $conn->error;
        }
    } else {
        $message = "❌ Error in registration: " . $conn->error;
    }
}
?>

<?php include('header.php'); ?>

<div class="auth-container">
    <div class="auth-card">
        <div class="text-center mb-4">
            <i class="fas fa-chalkboard-teacher fa-3x mb-3" style="color: #1E3A8A;"></i>
            <h2 class="auth-title">Tutor Registration</h2>
            <p class="text-muted">Join our team of expert tutors</p>
        </div>

        <div class="alert alert-warning mb-4">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Important Note:</strong> Please ensure all information provided is accurate and complete. Your
            location will be used to match you with nearby students, so please verify your location on the map is
            correct before submitting.
        </div>

        <?php if (isset($message)): ?>
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle me-2"></i><?= $message ?>
        </div>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-user me-2"></i>Full Name
                </label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-envelope me-2"></i>Email Address
                </label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <!-- Add this after the email input field in the form -->
            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-phone me-2"></i>Phone Number
                </label>
                <input type="tel" name="phone" class="form-control"
                    title="Please enter a valid 10-digit phone number" required value=+91 >
                <small class="form-text text-muted">Enter a 10-digit phone number without spaces or special
                    characters</small>
            </div>


            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-lock me-2"></i>Password
                </label>
                <div class="input-group">
                    <input type="password" name="password" class="form-control" id="password" required>
                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-graduation-cap me-2"></i>Qualification
                </label>
                <select name="qualification" class="form-control" required>
                    <option value="">Select Your Highest Qualification</option>
                    <option value="Bachelors">Bachelor's Degree</option>
                    <option value="Masters">Master's Degree</option>
                    <option value="PhD">PhD</option>
                    <option value="BEd">B.Ed</option>
                    <option value="MEd">M.Ed</option>
                    <option value="Diploma">Diploma</option>
                    <option value="Certification">Professional Certification</option>
                    <option value="Other">Other</option>
                </select>
                <small class="form-text text-muted">Please select your highest educational qualification</small>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-book me-2"></i>Classes You Can Teach
                </label>
                <div class="checkbox-group">
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="teaching_classes[]" value="Class 1-5"
                            id="class1-5">
                        <label class="form-check-label" for="class1-5">Class 1–5</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="teaching_classes[]" value="Class 6-8"
                            id="class6-8">
                        <label class="form-check-label" for="class6-8">Class 6–8</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="teaching_classes[]" value="Class 9-10"
                            id="class9-10">
                        <label class="form-check-label" for="class9-10">Class 9–10</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="teaching_classes[]"
                            value="Class 11-12 Science" id="class11-12-science">
                        <label class="form-check-label" for="class11-12-science">Class 11–12 (Science)</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="teaching_classes[]"
                            value="Class 11-12 Commerce" id="class11-12-commerce">
                        <label class="form-check-label" for="class11-12-commerce">Class 11–12 (Commerce)</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="teaching_classes[]"
                            value="Class 11-12 Arts" id="class11-12-arts">
                        <label class="form-check-label" for="class11-12-arts">Class 11–12 (Arts)</label>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-book-open me-2"></i>Subject Expertise
                </label>
                <select name="subject_expertise" class="form-control" required>
                    <option value="">Select Subject</option>
                    <?php
                    $subject_query = $conn->query("SELECT * FROM subjects ORDER BY name ASC");
                    while ($row = $subject_query->fetch_assoc()) {
                        echo "<option value='{$row['name']}'>{$row['name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">
                    <i class="fas fa-map-marker-alt me-2"></i>Location
                </label>
                <input type="text" id="autocomplete" placeholder="Search your location" class="form-control">
                <input type="hidden" name="latitude" id="latitude" required>
                <input type="hidden" name="longitude" id="longitude" required>
            </div>

            <div id="map" class="map-box mb-4" style="height: 200px; border-radius: 8px; overflow: hidden;"></div>

            <button type="submit" class="btn btn-primary auth-btn">
                <i class="fas fa-user-plus me-2"></i>Register
            </button>
        </form>
    </div>
</div>

<style>
.auth-container {
    min-height: calc(100vh - 76px);
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 2rem;
}

.auth-card {
    background: white;
    padding: 2.5rem;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
}

.auth-title {
    color: #1E3A8A;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-label {
    color: #495057;
    font-weight: 500;
    margin-bottom: 0.5rem;
    display: block;
}

.form-control {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: #1E3A8A;
    box-shadow: 0 0 0 0.2rem rgba(30, 58, 138, 0.15);
}

.checkbox-group {
    background: #f8f9fa;
    padding: 1rem;
    border-radius: 8px;
    border: 1px solid #e9ecef;
}

.form-check-input:checked {
    background-color: #1E3A8A;
    border-color: #1E3A8A;
}

.auth-btn {
    background: linear-gradient(135deg, #1E3A8A, #0F1C4D);
    border: none;
    border-radius: 8px;
    padding: 0.75rem;
    font-weight: 600;
    width: 100%;
    transition: all 0.3s ease;
}

.auth-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(30, 58, 138, 0.3);
}

.alert {
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 1.5rem;
}

.map-box {
    border: 2px solid #e9ecef;
}

@media (max-width: 576px) {
    .auth-card {
        padding: 2rem 1.5rem;
    }

    .auth-container {
        padding: 1rem;
    }
}

.input-group {
    position: relative;
}

.input-group .btn {
    border-color: #e9ecef;
    background: transparent;
    transition: all 0.3s ease;
}

.input-group .btn:hover {
    background: rgba(30, 58, 138, 0.1);
    border-color: #1E3A8A;
}

.input-group .btn i {
    color: #1E3A8A;
}

.form-text {
    color: #6c757d;
    font-size: 0.875rem;
    margin-top: 0.25rem;
}
</style>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYqMA1rU_SMUIopL228VhSWtdkJ5Dvxdc&libraries=places">
</script>
<script>
let map, marker, autocomplete;

function initMap() {
    const defaultLatLng = {
        lat: 30.900965,
        lng: 75.857277
    };
    map = new google.maps.Map(document.getElementById("map"), {
        center: defaultLatLng,
        zoom: 14,
        styles: [{
            featureType: "all",
            elementType: "labels.text.fill",
            stylers: [{
                color: "#1E3A8A"
            }]
        }]
    });

    marker = new google.maps.Marker({
        map: map,
        position: defaultLatLng,
        draggable: true,
        animation: google.maps.Animation.DROP
    });

    autocomplete = new google.maps.places.Autocomplete(document.getElementById('autocomplete'));
    autocomplete.addListener('place_changed', function() {
        const place = autocomplete.getPlace();
        if (!place.geometry || !place.geometry.location) return;

        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();

        document.getElementById('latitude').value = lat;
        document.getElementById('longitude').value = lng;

        map.setCenter({
            lat,
            lng
        });
        marker.setPosition({
            lat,
            lng
        });
    });

    marker.addListener('dragend', function() {
        const lat = marker.getPosition().lat();
        const lng = marker.getPosition().lng();

        document.getElementById('latitude').value = lat;
        document.getElementById('longitude').value = lng;
    });
}

window.onload = initMap;

document.addEventListener('DOMContentLoaded', function() {
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password');

    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });
});
</script>


<?php include 'footer.php'; ?>