<?php include 'header.php'; ?>

<div class="container py-5">
    <h1 class="text-center mb-5">Find Your Perfect Tutor</h1>

    <!-- Search and Filter Section -->
    <div class="card shadow-sm mb-5">
        <div class="card-body">
            <form class="row g-3">
                <div class="col-md-3">
                    <label for="subject" class="form-label">Subject</label>
                    <select class="form-select" id="subject">
                        <option value="">All Subjects</option>
                        <option>Mathematics</option>
                        <option>Science</option>
                        <option>English</option>
                        <option>History</option>
                        <option>Languages</option>
                        <option>Computer Science</option>
                        <option>Business Studies</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="level" class="form-label">Level</label>
                    <select class="form-select" id="level">
                        <option value="">All Levels</option>
                        <option>Elementary</option>
                        <option>Middle School</option>
                        <option>High School</option>
                        <option>College</option>
                        <option>Adult</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="location" class="form-label">Location</label>
                    <select class="form-select" id="location">
                        <option value="">All Locations</option>
                        <option>Online</option>
                        <option>In-Person</option>
                        <option>Both</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="experience" class="form-label">Experience</label>
                    <select class="form-select" id="experience">
                        <option value="">Any Experience</option>
                        <option>1-2 years</option>
                        <option>3-5 years</option>
                        <option>5+ years</option>
                    </select>
                </div>
                <div class="col-12 text-center">
                    <button type="submit" class="btn btn-primary">Search Tutors</button>
                    <button type="reset" class="btn btn-outline-secondary ms-2">Reset Filters</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Sort Options -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center">
            <span class="me-2">Sort by:</span>
            <div class="btn-group">
                <button type="button" class="btn btn-outline-primary active">Rating</button>
                <button type="button" class="btn btn-outline-primary">Experience</button>
                <button type="button" class="btn btn-outline-primary">Price</button>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <span class="me-2">View:</span>
            <div class="btn-group">
                <button type="button" class="btn btn-outline-primary active"><i class="fas fa-th-large"></i></button>
                <button type="button" class="btn btn-outline-primary"><i class="fas fa-list"></i></button>
            </div>
        </div>
    </div>

    <!-- Tutors Grid -->
    <div class="row">
        <!-- Tutor Card 1 -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm hover-shadow">
                <div class="position-relative">
                    <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Tutor">
                    <div class="position-absolute top-0 end-0 m-2">
                        <span class="badge bg-success">Available Now</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="card-title mb-1">Sarah Johnson</h5>
                            <p class="text-muted mb-0">Mathematics Tutor</p>
                        </div>
                        <div class="text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                            <span class="text-muted">(4.9)</span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <span class="badge bg-primary me-2">5+ years experience</span>
                        <span class="badge bg-info">Online</span>
                    </div>
                    <p class="card-text">Specialized in Algebra and Calculus. Passionate about making math fun and accessible for all students.</p>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-graduation-cap text-primary me-2"></i>M.Sc. Mathematics</li>
                        <li class="mb-2"><i class="fas fa-map-marker-alt text-primary me-2"></i>Available Online</li>
                        <li class="mb-2"><i class="fas fa-dollar-sign text-primary me-2"></i>$25/hour</li>
                    </ul>
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary">View Profile</button>
                        <button class="btn btn-outline-primary">Book Session</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tutor Card 2 -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm hover-shadow">
                <div class="position-relative">
                    <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Tutor">
                    <div class="position-absolute top-0 end-0 m-2">
                        <span class="badge bg-success">Available Now</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="card-title mb-1">Michael Chen</h5>
                            <p class="text-muted mb-0">Science Tutor</p>
                        </div>
                        <div class="text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <span class="text-muted">(5.0)</span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <span class="badge bg-primary me-2">8+ years experience</span>
                        <span class="badge bg-info">In-Person</span>
                    </div>
                    <p class="card-text">Expert in Physics and Chemistry. Focuses on practical applications and real-world examples.</p>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-graduation-cap text-primary me-2"></i>Ph.D. Physics</li>
                        <li class="mb-2"><i class="fas fa-map-marker-alt text-primary me-2"></i>Available In-Person</li>
                        <li class="mb-2"><i class="fas fa-dollar-sign text-primary me-2"></i>$30/hour</li>
                    </ul>
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary">View Profile</button>
                        <button class="btn btn-outline-primary">Book Session</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tutor Card 3 -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm hover-shadow">
                <div class="position-relative">
                    <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Tutor">
                    <div class="position-absolute top-0 end-0 m-2">
                        <span class="badge bg-warning">Available Soon</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="card-title mb-1">Emily Rodriguez</h5>
                            <p class="text-muted mb-0">Language Tutor</p>
                        </div>
                        <div class="text-warning">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="far fa-star"></i>
                            <span class="text-muted">(4.0)</span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <span class="badge bg-primary me-2">6+ years experience</span>
                        <span class="badge bg-info">Both</span>
                    </div>
                    <p class="card-text">Native Spanish speaker with expertise in teaching Spanish and English as second languages.</p>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-graduation-cap text-primary me-2"></i>M.A. Linguistics</li>
                        <li class="mb-2"><i class="fas fa-map-marker-alt text-primary me-2"></i>Available Both</li>
                        <li class="mb-2"><i class="fas fa-dollar-sign text-primary me-2"></i>$22/hour</li>
                    </ul>
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary">View Profile</button>
                        <button class="btn btn-outline-primary">Book Session</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add more tutor cards as needed -->
    </div>

    <!-- Pagination -->
    <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center">
            <li class="page-item disabled">
                <a class="page-link" href="#" tabindex="-1">Previous</a>
            </li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item">
                <a class="page-link" href="#">Next</a>
            </li>
        </ul>
    </nav>
</div>

<style>
.hover-shadow {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-shadow:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
}
.card-img-top {
    height: 200px;
    object-fit: cover;
}
</style>

<?php include 'footer.php'; ?> 